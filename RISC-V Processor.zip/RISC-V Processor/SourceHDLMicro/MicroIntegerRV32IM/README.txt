Dentro de esta carpeta se encuentra todo el microprocesador RISCV que soporta el set de instrucciones RV32I y la extensión de la multiplicación RV32M.

