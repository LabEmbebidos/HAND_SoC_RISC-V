Dentro de esta carpeta se encuentra el Main micro. Es el archivo .v donde se instancia el cpu con los PPI.
