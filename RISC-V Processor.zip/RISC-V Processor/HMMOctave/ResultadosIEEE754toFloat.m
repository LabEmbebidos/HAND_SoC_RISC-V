function [] = ResultadosIEEE754toFloat()

% N es el numero de filas del archivo monitorFiltro.csv por defecto es 148
fid = fopen('/home/carlos/XilinxMicroprocesadorMulticiclo/monitorHMMBosque.txt','r');  %# Open the file
data = textscan(fid,'%s');  %# Read the data
charArray = char(data{1});  %# Create a character array
fclose(fid);                %# Close the file);


fd1=fopen('ResultadosHMMBosqueXilinx.txt','wt');
values = typecast(uint32(hex2dec(charArray)),'single');
fprintf(fd1,'% 1.42f\n',values);
fclose(fd1);  





fid = fopen('/home/carlos/XilinxMicroprocesadorMulticiclo/monitorHMMMotosierra.txt','r');  %# Open the file
data = textscan(fid,'%s');  %# Read the data
charArray = char(data{1});  %# Create a character array
fclose(fid);                %# Close the file);


fd1=fopen('ResultadosHMMMotosierraXilinx.txt','wt');
values = typecast(uint32(hex2dec(charArray)),'single');
fprintf(fd1,'% 1.42f\n',values); 
fclose(fd1); 

fid = fopen('/home/carlos/XilinxMicroprocesadorMulticiclo/monitorHMMDisparo.txt','r');  %# Open the file
data = textscan(fid,'%s');  %# Read the data
charArray = char(data{1});  %# Create a character array
fclose(fid);                %# Close the file);


fd1=fopen('ResultadosHMMDisparoXilinx.txt','wt');
values = typecast(uint32(hex2dec(charArray)),'single');
fprintf(fd1,'% 1.42f\n',values);
fclose(fd1); 
