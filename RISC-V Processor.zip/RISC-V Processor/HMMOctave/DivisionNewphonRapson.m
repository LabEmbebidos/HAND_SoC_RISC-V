function p=DivisionNewphonRapson(N)
	%% Valido para valores de 0.5 a 1
	D=0.5;
	
	Xi=(48/17)-(32/17)*D;
	
	
	for i=1:N
		Xi = Xi*(2-D*Xi);
	end  
	
	p= Xi;


