function p=GenerarTrenesBinarios

Entrada=importdata('trenesEvaluacion.txt');
N = length(Entrada);
format long
fd=fopen('/home/carlos/XilinxMicroprocesadorMulticiclo/TrenesBinarios.txt','wt');

for k=1:N 
	fprintf(fd,'%s\n',dec2bin(Entrada(k),5));
end
p=1;

fclose(fd);

