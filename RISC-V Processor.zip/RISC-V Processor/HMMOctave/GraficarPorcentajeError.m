function p = GraficarPorcentajeError()

Datos_Teoricos = importdata('ResultadosHMMEvaluacionBosque.txt');
Datos_Salida_FPGA_Xilinx = importdata('ResultadosHMMBosqueXilinx.txt');

t=(1:length(Datos_Teoricos));

subplot(3,1,1)
plot(t,(100*(abs(Datos_Teoricos - Datos_Salida_FPGA_Xilinx)/abs(Datos_Teoricos)))),grid on
title('Resultados Porcentaje Error HMM Bosque')
legend('Porcentaje Error')




Datos_Teoricos = importdata('ResultadosHMMEvaluacionMotosierra.txt');
Datos_Salida_FPGA_Xilinx = importdata('ResultadosHMMMotosierraXilinx.txt');

t=(1:length(Datos_Teoricos));

subplot(3,1,2)
plot(t,(100*(abs(Datos_Teoricos - Datos_Salida_FPGA_Xilinx)/abs(Datos_Teoricos)))),grid on
title('Resultados Porcentaje Error HMM Motosierra')
legend('Porcentaje Error')



Datos_Teoricos = importdata('ResultadosHMMEvaluacionDisparo.txt');
Datos_Salida_FPGA_Xilinx = importdata('ResultadosHMMDisparoXilinx.txt');

t=(1:length(Datos_Teoricos));

subplot(3,1,3)
plot(t,(100*(abs(Datos_Teoricos - Datos_Salida_FPGA_Xilinx)/abs(Datos_Teoricos)))),grid on
title('Resultados Porcentaje Error HMM Disparo')
legend('Porcentaje Error')
