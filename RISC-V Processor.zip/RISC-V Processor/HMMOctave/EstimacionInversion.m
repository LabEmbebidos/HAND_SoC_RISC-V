function p=EstimacionInversion(num,N)


x= num-1;
sum = 1-x;
aux = -x;
x = aux*aux;
sum = sum +x;
for i=3:N
	x=aux*x;
	sum = sum + x;
end

p=sum;


%%     
%%
%%                              N
%%          1                                   i        i
%%     ------------      =    sum           (-1)   *   x
%%        x + 1					
%%                              i=0
