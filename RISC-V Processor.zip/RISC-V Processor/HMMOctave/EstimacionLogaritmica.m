function p=EstimacionLogaritmica(num,N)
















%%                                                                        2*n + 1
%%                      inf                       |     2               |
%%                                  1             |    x     -     1    |
%%     Ln(x)   =   sumatoria  ----------------  * |---------------------|
%%	                             2*n  +  1        |      2              |
%%                      n=0                       |_    x     +     1  _|
%%
%%
%%
