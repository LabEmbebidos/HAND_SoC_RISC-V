function p=ImplementacionDivision(num,den)
	format long
	%%% Simulación de función en C del algoritmo
	%%% El algoritmo solo sirve para valores de denominador positivos mayores que 0
	%%El numerador es válido para cualquier número real
	if den <0
		den = -den;
		num = -num;
	end
	
	escala=1.0;%% constante de escala
	loopp=1;
	while loopp ==1 %% Escala los números a un rango entre 0.1 y 1
		if den>1
			if den>10000000
				escala = escala*(1/10000000);
				den = den*(1/10000000);
			elseif den>1000000
				escala = escala*(1/1000000);
				den = den*(1/1000000);
			elseif den>100000
				escala = escala*(1/100000);
				den = den*(1/100000);
			elseif den>10000
				escala = escala*(1/10000);
				den = den*(1/10000);
			elseif den>1000
				escala = escala*(1/1000);
				den = den*(1/1000);
			elseif den>100
				escala = escala*(1/100);
				den = den*(1/100);
			else den>10
				escala = escala*(1/10);
				den = den*(1/10);
			end
		else
			if den < 0.00001 %% Si denominador es menor a 0.00001 va durar muchas iteraciones por lo que se prefiere escalar
				escala = escala*100000;
				den = den*100000;
			elseif den < 0.0001 %% Si denominador es menor a 0.0001 va durar muchas iteraciones por lo que se prefiere escalar
				escala = escala*10000;
				den = den*10000;
			elseif den < 0.001 %% Si denominador es menor a 0.001 va durar muchas iteraciones por lo que se prefiere escalar
				escala = escala*1000;
				den = den*1000;
			elseif den < 0.01 %% Si denominador es menor a 0.01 va durar muchas iteraciones por lo que se prefiere escalar
				escala = escala*100;
				den = den*100;
			elseif den < 0.1 %% Si denominador es menor a 0.1 va durar muchas iteraciones por lo que se prefiere escalar
				escala = escala*10;
				den = den*10;
			else
				loopp =0;
			end
		end
	end 
	
	%% Determina el número de iteraciones
	
	if den>0.5
		N=4;
	else 
		N=6;
	end
	
	fprintf('La escala es: %e \n', escala);
        fprintf('La denomnador es: %e \n',den);
	
	%% Ejecuta Newphon Rapson
	D=den;
		
	Xi=(48/17)-(32/17)*D;
	
	for i=1:N
		Xi = Xi*(2-D*Xi);
	end  
	 
	
	if num==1 %% Si numerador es 1
		if escala == 1  %% Si no hay escala
			p = Xi;
		else            %% Si sí hubo escala
			p= Xi*escala;
		end
	else  %% Si numerador no es 1
		if escala == 1  %% Si no hay escala
			p= Xi*num;
		else	%% Si sí hubo escala
			p= Xi*num*escala;
		end
	end
