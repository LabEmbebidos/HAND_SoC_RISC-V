function [] = GraficarResultadosHMM()

Datos_Teoricos = importdata('ResultadosHMMEvaluacionBosque.txt');
Datos_Salida_FPGA_Xilinx = importdata('ResultadosHMMBosqueXilinx.txt');

t=(1:length(Datos_Teoricos));

subplot(3,1,1)
plot(t,Datos_Salida_FPGA_Xilinx,t,Datos_Teoricos),grid on
title('Resultados HMM Bosque')
legend('Datos Obtenidos', 'Datos Teóricos')



Datos_Teoricos = importdata('ResultadosHMMEvaluacionMotosierra.txt');
Datos_Salida_FPGA_Xilinx = importdata('ResultadosHMMMotosierraXilinx.txt');

t=(1:length(Datos_Teoricos));

subplot(3,1,2)
plot(t,Datos_Salida_FPGA_Xilinx,t,Datos_Teoricos),grid on
title('Resultados HMM Motosierra')
legend('Datos Obtenidos', 'Datos Teóricos')




Datos_Teoricos = importdata('ResultadosHMMEvaluacionDisparo.txt');
Datos_Salida_FPGA_Xilinx = importdata('ResultadosHMMDisparoXilinx.txt');

t=(1:length(Datos_Teoricos));

subplot(3,1,3)
plot(t,Datos_Salida_FPGA_Xilinx,t,Datos_Teoricos),grid on
title('Resultados HMM Disparo')
legend('Datos Obtenidos', 'Datos Teóricos')




