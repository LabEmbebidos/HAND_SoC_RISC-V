
char * dec2bin(int num, int N);
