/*
 * ELABORADO POR: CARLOS ADRIÁN SALAZAR GARCÍA
 * csalazar@itcr.ac.cr
 * DCILAB
 * PROGRAMA QUE CONVIERTE DE ENTERO CON SIGNO A BINARIO EN COMPLEMENTO A 2
*/

#include <stdio.h>
#include <math.h>
#include <string.h>
#include "dec2bin.h"



char * dec2bin(int num, int N)
{
	static char  BinarioNumero[70]; // Variable char que va a retornar el arreglo
	int i; // Variables para el for
	int signo = 0; // Signo si es 0 es positivo si es 1 negativo
	int EncontroUnUno = 0; //Señal que indica si encontró o no un uno
	double residuo; // residuo de la operación
	int originalnum = num; // número original se usa para corregir un error al realizar complemento a 2
  
	if(num<0) // Si el número es negativo, se convierte positivo pero el bit MSB se pone en 1 si es negativo o en 0 si es positivo
	{
		BinarioNumero[0] = '1';
		num = -num;
		signo = 1;
	}
	else 
		BinarioNumero[0] = '0';
	
	// Se realiza la conversión de decimal a binario, como si el número fuera positivo
	for (i=1;i<=N-1;i++){ 
		residuo = num/pow(2,N-i-1);
		if (residuo >= 1){
			BinarioNumero[i] = '1';
			num = num - pow(2,N-i-1);
		}
		else {
			BinarioNumero[i] = '0';
		}
	}
	
	//Se realiza el complemento a 2 del número anterior solo en caso de que el número sea negativo, si es positivo queda igual
	if(BinarioNumero[0] == '1') // Si el número es negativo se convierte la cantidad a positiva
	{
		for (i=N-1;i>=1;i--) // Empiezo a buscar si hay un 1 en la posición LSB hacia la MSB
		{   // Mientras no encuentre un 1, no sucede nada
			if(BinarioNumero[i] == '1')  // En el momento que aparezca un 1 verifica si la variable signo es igual a 1, si es 1 invierte los números y si no en ese momento la variable signo se pone igual a 1, complemento a 2 por esencia
			{
				if(EncontroUnUno==1) // Si signo ya era igual a 1 invierte la cadena de caracteres. Es decir 1 se convierte en 0 y 0 en 1
				{	
					if(BinarioNumero[i] == '1')
						BinarioNumero[i] = '0';
					else
						BinarioNumero[i] = '1';
				}
				EncontroUnUno = 1;
			}
			else  
			{
				if(EncontroUnUno==1)
				{
					if(BinarioNumero[i] == '1')
						BinarioNumero[i] = '0';
					else
						BinarioNumero[i] = '1';
				}
			}
		}
	}
	
	// Por error en la forma de conversión de complemento a dos el máximo negativo falla por un 1 en la posición LSB, por esta razón se le realiza un ajuste a la misma
	if(originalnum==-pow(2,N-1)) // Si el número original es igual al menor negativo que se puede representar su posición LSB se convierte a negativo
		BinarioNumero[N-1] = '0';
	
	return BinarioNumero; // Se retorna un array de tipo char con el número en binario
}
