
// gcc GeneradorDatosTeoricos.c dec2bin.c -o GeneradorDatosTeoricos.o -lm -lncurses



#include <ncurses.h>
#include <stdlib.h>
#include <stdio.h>
#include <math.h>
#include <string.h>
#include "dec2bin.h"

void menuSignedUnsigned(int yposition, int Operation, int vectorsize, int wordsize){
	WINDOW *wmenu2;
	char listmenu2[2][10] = { "Unsigned", "Signed"};
    char itemmenu2[10];
    int chmenu2, j = 0, widthmenu2 = 10;
    
    
	wmenu2 = newwin( 4, 13,yposition, 27 ); // create a new window (largo,ancho, y,x)
    box( wmenu2, 0, 0 ); // sets default borders for the window
    
    for( j=0; j<2; j++ ) {
        if( j == 0 ) 
            wattron( wmenu2, A_STANDOUT ); // highlights the first item.
        else
            wattroff( wmenu2, A_STANDOUT );
        sprintf(itemmenu2, "%-10s",  listmenu2[j]);
        mvwprintw( wmenu2, j+1, 2, "%s", itemmenu2 );
    }
    
    wrefresh( wmenu2 );
    j = 0;
    
    noecho(); // disable echoing of characters on the screen
    keypad( wmenu2, TRUE ); // enable keyboard input for the window.
    curs_set( 0 ); // hide the default screen cursor.
    
    while(( chmenu2 = wgetch(wmenu2)) != KEY_LEFT){ 
         
                // right pad with spaces to make the items appear with even width.
            sprintf(itemmenu2, "%-10s",  listmenu2[j]); 
            mvwprintw( wmenu2, j+1, 2, "%s", itemmenu2 ); 
              // use a variable to increment or decrement the value based on the input.
            switch( chmenu2 ) {
                case KEY_UP:
                            j--;
                            j = ( j<0 ) ? 1 : j;
                            break;
                case KEY_DOWN:
                            j++;
                            j = ( j>1 ) ? 0 : j;
                            break;
                case KEY_RIGHT:
                            
							GoldenReferences(Operation,vectorsize,wordsize,j);

                            
                            break;
            }
            // now highlight the next item in the list.
            wattron( wmenu2, A_STANDOUT );
             
            sprintf(itemmenu2, "%-10s",  listmenu2[j]);
            mvwprintw( wmenu2, j+1, 2, "%s", itemmenu2);
            wattroff( wmenu2, A_STANDOUT );
    }
    wrefresh( wmenu2 );

    //wborder(wmenu2, ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' '); // Erase frame around the window
    //wrefresh( wmenu2 );
    delwin( wmenu2 );
    
	
}

int menuWordLenght(int defaultsize){
	WINDOW *wWordLenght;
	char listmenu2[5][10] = { "8","16","24","32","64"};
    char itemmenu2[10];
    int chmenu2, j = 0, widthmenu2 = 10;
    
	wWordLenght = newwin( 7, 13, 1, 27 ); // create a new window (largo,ancho, y,x)
    box( wWordLenght, 0, 0 ); // sets default borders for the window
    
    for( j=0; j<5; j++ ) {
        if( j == defaultsize ) {
            wattron( wWordLenght, A_STANDOUT ); // highlights the first item.
            sprintf(itemmenu2, "*%-9s",  listmenu2[j]);
			mvwprintw( wWordLenght, j+1, 2, "%s", itemmenu2 );
        }else{
			wattroff( wWordLenght, A_STANDOUT );
			sprintf(itemmenu2, "%-10s",  listmenu2[j]);
			mvwprintw( wWordLenght, j+1, 2, "%s", itemmenu2 );
		}
    }
    
    wrefresh( wWordLenght );
    j = defaultsize;
    
    noecho(); // disable echoing of characters on the screen
    keypad( wWordLenght, TRUE ); // enable keyboard input for the window.
    curs_set( 0 ); // hide the default screen cursor.
    
    while( (chmenu2 = wgetch(wWordLenght)) != KEY_LEFT){ 
    //while(((chmenu2 = wgetch(wWordLenght)) != KEY_LEFT)){ 
         
                // right pad with spaces to make the items appear with even width.
            if(j==defaultsize){    
				sprintf(itemmenu2, "*%-9s",  listmenu2[j]);
				mvwprintw( wWordLenght, j+1, 2, "%s", itemmenu2 );
				//box( wWordLenght, 0, 0 );
			} else{
				sprintf(itemmenu2, "%-10s",  listmenu2[j]);
				mvwprintw( wWordLenght, j+1, 2, "%s", itemmenu2 );
			}
              // use a variable to increment or decrement the value based on the input.
            switch( chmenu2 ) {
                case KEY_UP:
                            j--;
                            j = ( j<0 ) ? 4 : j;
                            break;
                case KEY_DOWN:
                            j++;
                            j = ( j>4 ) ? 0 : j;
                            break;
                case KEY_RIGHT:
                            sprintf(itemmenu2, "%-10s",  listmenu2[defaultsize]);
							mvwprintw( wWordLenght, defaultsize+1, 2, "%s", itemmenu2 );
                            defaultsize = j;
                            break;
                 default:
							break;
            }
            // now highlight the next item in the list.
            wattron( wWordLenght, A_STANDOUT );
             
            if(j==defaultsize){    
				sprintf(itemmenu2, "*%-9s",  listmenu2[j]);
				mvwprintw( wWordLenght, j+1, 2, "%s", itemmenu2 );
				//box( wWordLenght, 0, 0 );
			} else{
				sprintf(itemmenu2, "%-10s",  listmenu2[j]);
				mvwprintw( wWordLenght, j+1, 2, "%s", itemmenu2 );
			}
            wattroff( wWordLenght, A_STANDOUT );
            
    }
    
    wrefresh( wWordLenght );

    //wborder(wmenu2, ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' '); // Erase frame around the window
    //wrefresh( wmenu2 );
    delwin( wWordLenght );
	
	return defaultsize;
}

void menuEjecutando(){
	WINDOW *wmenu2;
	char listmenu2[5][52] = {"////////////////////////////////////////////////",
		                     "///                                          ///",
		                     "///      Calculando Modelo de Referencia     ///",
		                     "///                                          ///",
		                     "////////////////////////////////////////////////"}; // 
    char itemmenu2[52];
    int chmenu2, j = 0, widthmenu2 = 52;
    
	wmenu2 = newwin( 7, 55,6, 60 ); // create a new window (largo,ancho, y,x)
    box( wmenu2, 0, 0 ); // sets default borders for the window
    
    for( j=0; j<5; j++ ) {
        
        wattroff( wmenu2, A_STANDOUT );
        sprintf(itemmenu2, "%-52s",  listmenu2[j]);
        mvwprintw( wmenu2, j+1, 2, "%s", itemmenu2 );
    }
    
    wrefresh( wmenu2 );
    noecho(); // disable echoing of characters on the screen
    keypad( wmenu2, TRUE ); // enable keyboard input for the window.
    curs_set( 0 ); // hide the default screen cursor.

    delwin( wmenu2 );
}

int menuMUL(int MULtype){
	WINDOW *wMUL;
	char listmenu2[4][10] = { "MUL","MULH","MULHU","MULHSU"};
    char itemmenu2[10];
    int chmenu2, j = 0, widthmenu2 = 10;
    
	wMUL = newwin( 6, 13, 12, 27 ); // create a new window (largo,ancho, y,x)
    box( wMUL, 0, 0 ); // sets default borders for the window
    
    for( j=0; j<4; j++ ) {
        if( j == MULtype ) {
            wattron( wMUL, A_STANDOUT ); // highlights the first item.
            sprintf(itemmenu2, "*%-9s",  listmenu2[j]);
			mvwprintw( wMUL, j+1, 2, "%s", itemmenu2 );
        }else{
			wattroff( wMUL, A_STANDOUT );
			sprintf(itemmenu2, "%-10s",  listmenu2[j]);
			mvwprintw( wMUL, j+1, 2, "%s", itemmenu2 );
		}
    }
    
    wrefresh( wMUL );
    j = MULtype;
    
    noecho(); // disable echoing of characters on the screen
    keypad( wMUL, TRUE ); // enable keyboard input for the window.
    curs_set( 0 ); // hide the default screen cursor.
    
    while( (chmenu2 = wgetch(wMUL)) != KEY_LEFT){ 
    //while(((chmenu2 = wgetch(wWordLenght)) != KEY_LEFT)){ 
         
                // right pad with spaces to make the items appear with even width.
            if(j==MULtype){    
				sprintf(itemmenu2, "*%-9s",  listmenu2[j]);
				mvwprintw( wMUL, j+1, 2, "%s", itemmenu2 );
				//box( wWordLenght, 0, 0 );
			} else{
				sprintf(itemmenu2, "%-10s",  listmenu2[j]);
				mvwprintw( wMUL, j+1, 2, "%s", itemmenu2 );
			}
              // use a variable to increment or decrement the value based on the input.
            switch( chmenu2 ) {
                case KEY_UP:
                            j--;
                            j = ( j<0 ) ? 3 : j;
                            break;
                case KEY_DOWN:
                            j++;
                            j = ( j>3 ) ? 0 : j;
                            break;
                case KEY_RIGHT:
                            sprintf(itemmenu2, "%-10s",  listmenu2[MULtype]);
							mvwprintw( wMUL, MULtype+1, 2, "%s", itemmenu2 );
                            MULtype = j;
                            break;
                 default:
							break;
            }
            // now highlight the next item in the list.
            wattron( wMUL, A_STANDOUT );
             
            if(j==MULtype){    
				sprintf(itemmenu2, "*%-9s",  listmenu2[j]);
				mvwprintw( wMUL, j+1, 2, "%s", itemmenu2 );
				//box( wWordLenght, 0, 0 );
			} else{
				sprintf(itemmenu2, "%-10s",  listmenu2[j]);
				mvwprintw( wMUL, j+1, 2, "%s", itemmenu2 );
			}
            wattroff( wMUL, A_STANDOUT );
            
    }
    
    wrefresh( wMUL );

    //wborder(wmenu2, ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' '); // Erase frame around the window
    //wrefresh( wmenu2 );
    delwin( wMUL );
	
	return MULtype;
}

int menuTestVector(int defaultsize){
	WINDOW *wTestVector;
	char listmenu2[11][10] = { "256","512","1024","4096","16384","32758","65536","131072","262144","524288","1048576"};
    char itemmenu2[10];
    int chmenu2, j = 0, widthmenu2 = 10;
    
	wTestVector = newwin( 13, 13, 2, 27 ); // create a new window (largo,ancho, y,x)
    box( wTestVector, 0, 0 ); // sets default borders for the window
    
    for( j=0; j<11; j++ ) {
        if( j == defaultsize ) {
            wattron( wTestVector, A_STANDOUT ); // highlights the first item.
            sprintf(itemmenu2, "*%-9s",  listmenu2[j]);
			mvwprintw( wTestVector, j+1, 2, "%s", itemmenu2 );
        }else{
			wattroff( wTestVector, A_STANDOUT );
			sprintf(itemmenu2, "%-10s",  listmenu2[j]);
			mvwprintw( wTestVector, j+1, 2, "%s", itemmenu2 );
		}
    }
    
    wrefresh( wTestVector );
    j = defaultsize;
    
    noecho(); // disable echoing of characters on the screen
    keypad( wTestVector, TRUE ); // enable keyboard input for the window.
    curs_set( 0 ); // hide the default screen cursor.
    
    while( (chmenu2 = wgetch(wTestVector)) != KEY_LEFT){ 
    //while(((chmenu2 = wgetch(wWordLenght)) != KEY_LEFT)){ 
         
                // right pad with spaces to make the items appear with even width.
            if(j==defaultsize){    
				sprintf(itemmenu2, "*%-9s",  listmenu2[j]);
				mvwprintw( wTestVector, j+1, 2, "%s", itemmenu2 );
				//box( wWordLenght, 0, 0 );
			} else{
				sprintf(itemmenu2, "%-10s",  listmenu2[j]);
				mvwprintw( wTestVector, j+1, 2, "%s", itemmenu2 );
			}
              // use a variable to increment or decrement the value based on the input.
            switch( chmenu2 ) {
                case KEY_UP:
                            j--;
                            j = ( j<0 ) ? 10 : j;
                            break;
                case KEY_DOWN:
                            j++;
                            j = ( j>10 ) ? 0 : j;
                            break;
                case KEY_RIGHT:
                            sprintf(itemmenu2, "%-10s",  listmenu2[defaultsize]);
							mvwprintw( wTestVector, defaultsize+1, 2, "%s", itemmenu2 );
                            defaultsize = j;
                            break;
                 default:
							break;
            }
            // now highlight the next item in the list.
            wattron( wTestVector, A_STANDOUT );
             
            if(j==defaultsize){    
				sprintf(itemmenu2, "*%-9s",  listmenu2[j]);
				mvwprintw( wTestVector, j+1, 2, "%s", itemmenu2 );
				//box( wWordLenght, 0, 0 );
			} else{
				sprintf(itemmenu2, "%-10s",  listmenu2[j]);
				mvwprintw( wTestVector, j+1, 2, "%s", itemmenu2 );
			}
            wattroff( wTestVector, A_STANDOUT );
            
    }
    
    wrefresh( wTestVector );

    //wborder(wmenu2, ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' '); // Erase frame around the window
    //wrefresh( wmenu2 );
    delwin( wTestVector );
	
	return defaultsize;
}


void GoldenReferences(int Operation, int vectorSize, int wordsize, int signed1orUnsigned){
	FILE * fp;
    FILE * fp1;
    FILE * fp2;
    time_t t;
    
    
    fp = fopen ("VectorEntradaXilinx.txt", "w+");
    fp1 = fopen ("VectorEntradaTeoricoC.txt", "w+");
	fp2 = fopen ("VectorSalidaTeorico.txt", "w+");
   
   
   
	
    if(wordsize==0) wordsize = 8;
    else if(wordsize==1) wordsize = 16;
    else if(wordsize==2) wordsize = 24;
    else if(wordsize==3) wordsize = 32;
    else wordsize = 64;
    
    
    
    if(vectorSize==0) vectorSize = 256;
    else if(vectorSize==1) vectorSize = 512; 
    else if(vectorSize==2) vectorSize = 1024; 
    else if(vectorSize==3) vectorSize = 4096; 
    else if(vectorSize==4) vectorSize = 16384; 
    else if(vectorSize==5) vectorSize = 32758; 
    else if(vectorSize==6) vectorSize = 65536; 
    else if(vectorSize==7) vectorSize = 131072; 
    else if(vectorSize==8) vectorSize = 262144; 
    else if(vectorSize==9) vectorSize = 524288; 
    else vectorSize = 1048576; 
   
    
    
    char BinarioNumero[70] ;
    /* Intializes random number generator */
    srand((unsigned) time(&t));
    
    int *ArrayRS1;
    int *ArrayRS2;
    
    
    int i =0;
    int Resultado;
    int AlcanceNumerico = 0;
    AlcanceNumerico = (int)pow(2,wordsize-1)-1;
    
    int Signo1 = 0;
    Signo1 = (rand() % 2);
    Signo1 = (int)pow(-1,Signo1);
    
    ArrayRS1=(int*)malloc(vectorSize*sizeof(int));
    ArrayRS2=(int*)malloc(vectorSize*sizeof(int));
    if(ArrayRS1==NULL || ArrayRS2==NULL)                     
    {
        printf("Error! memory not allocated.");
        exit(0);
    }
    
    
    
    
	if(Operation==2){ //Add
		    for( i = 0 ; i < vectorSize ; i++ ) 
		   {
			  do
			  {
				  Signo1 = (rand() % 2);
				  Signo1 = (int)pow(-1,Signo1);
				  *(ArrayRS1 + i) = Signo1*(rand() % (AlcanceNumerico+1)) ;
				  Signo1 = (rand() % 2);
				  Signo1 = (int)pow(-1,Signo1);
				  *(ArrayRS2 + i) = Signo1*(rand() % (AlcanceNumerico+1))  ;
				  Resultado = *(ArrayRS1 + i) + *(ArrayRS2 + i);

			  }while( Resultado>AlcanceNumerico || Resultado<-AlcanceNumerico-1);
			  
			  
			  strcpy(BinarioNumero,dec2bin(*(ArrayRS1 + i),wordsize)); // Así se copian  los string
			  fprintf(fp, "%s \t",BinarioNumero);
			  fprintf(fp1, "%d \t",*(ArrayRS1 + i));
			  
			  strcpy(BinarioNumero,dec2bin(*(ArrayRS2 + i),wordsize)); // Así se copian  los string
			  fprintf(fp, "%s \n",BinarioNumero);
			  fprintf(fp1, "%d \n",*(ArrayRS2 + i));
			  
			  fprintf(fp2, "%d \n",Resultado);
		   }
	}
	
	if(Operation==3){ //Left Shift
		    for( i = 0 ; i < vectorSize ; i++ ) 
		   {
			  do
			  {
				  Signo1 = (rand() % 2);
				  Signo1 = (int)pow(-1,Signo1);
				  *(ArrayRS1 + i) = Signo1*(rand() % (AlcanceNumerico+1)) ;

				  *(ArrayRS2 + i) = (rand() % 32)  ;
				  Resultado = *(ArrayRS1 + i) << *(ArrayRS2 + i);

			  }while( Resultado>AlcanceNumerico || Resultado<-AlcanceNumerico-1);
			  
			  
			  strcpy(BinarioNumero,dec2bin(*(ArrayRS1 + i),wordsize)); // Así se copian  los string
			  fprintf(fp, "%s \t",BinarioNumero);
			  fprintf(fp1, "%d \t",*(ArrayRS1 + i));
			  
			  strcpy(BinarioNumero,dec2bin(*(ArrayRS2 + i),wordsize)); // Así se copian  los string
			  fprintf(fp, "%s \n",BinarioNumero);
			  fprintf(fp1, "%d \n",*(ArrayRS2 + i));
			  
			  fprintf(fp2, "%d \n",Resultado);
		   }
	}
	
	if(Operation==4){  //Right Shift
		    for( i = 0 ; i < vectorSize ; i++ ) 
		   {
			  do
			  {
				  Signo1 = (rand() % 2);
				  Signo1 = (int)pow(-1,Signo1);
				  *(ArrayRS1 + i) = Signo1*(rand() % (AlcanceNumerico+1)) ;

				  *(ArrayRS2 + i) = (rand() % 32)  ;
				  Resultado = *(ArrayRS1 + i) >> *(ArrayRS2 + i);

			  }while( Resultado>AlcanceNumerico || Resultado<-AlcanceNumerico-1);
			  
			  
			  strcpy(BinarioNumero,dec2bin(*(ArrayRS1 + i),wordsize)); // Así se copian  los string
			  fprintf(fp, "%s \t",BinarioNumero);
			  fprintf(fp1, "%d \t",*(ArrayRS1 + i));
			  
			  strcpy(BinarioNumero,dec2bin(*(ArrayRS2 + i),wordsize)); // Así se copian  los string
			  fprintf(fp, "%s \n",BinarioNumero);
			  fprintf(fp1, "%d \n",*(ArrayRS2 + i));
			  
			  fprintf(fp2, "%d \n",Resultado);
		   }
	}
	
	if(Operation==6){ //AND
		    for( i = 0 ; i < vectorSize ; i++ ) 
		   {
			  
			  Signo1 = (rand() % 2);
			  Signo1 = (int)pow(-1,Signo1);
			  *(ArrayRS1 + i) = Signo1*(rand() % (AlcanceNumerico+1)) ;
			  Signo1 = (rand() % 2);
			  Signo1 = (int)pow(-1,Signo1);
			  *(ArrayRS2 + i) = Signo1*(rand() % (AlcanceNumerico+1))  ;
			  Resultado = *(ArrayRS1 + i) & *(ArrayRS2 + i);

			  strcpy(BinarioNumero,dec2bin(*(ArrayRS1 + i),wordsize)); // Así se copian  los string
			  fprintf(fp, "%s \t",BinarioNumero);
			  fprintf(fp1, "%d \t",*(ArrayRS1 + i));
			  
			  strcpy(BinarioNumero,dec2bin(*(ArrayRS2 + i),wordsize)); // Así se copian  los string
			  fprintf(fp, "%s \n",BinarioNumero);
			  fprintf(fp1, "%d \n",*(ArrayRS2 + i));
			  
			  fprintf(fp2, "%d \n",Resultado);
		   }
	}
	
	if(Operation==7){ //OR
		    for( i = 0 ; i < vectorSize ; i++ ) 
		   {
			  
			  Signo1 = (rand() % 2);
			  Signo1 = (int)pow(-1,Signo1);
			  *(ArrayRS1 + i) = Signo1*(rand() % (AlcanceNumerico+1)) ;
			  Signo1 = (rand() % 2);
			  Signo1 = (int)pow(-1,Signo1);
			  *(ArrayRS2 + i) = Signo1*(rand() % (AlcanceNumerico+1))  ;
			  Resultado = *(ArrayRS1 + i) | *(ArrayRS2 + i);

			  strcpy(BinarioNumero,dec2bin(*(ArrayRS1 + i),wordsize)); // Así se copian  los string
			  fprintf(fp, "%s \t",BinarioNumero);
			  fprintf(fp1, "%d \t",*(ArrayRS1 + i));
			  
			  strcpy(BinarioNumero,dec2bin(*(ArrayRS2 + i),wordsize)); // Así se copian  los string
			  fprintf(fp, "%s \n",BinarioNumero);
			  fprintf(fp1, "%d \n",*(ArrayRS2 + i));
			  
			  fprintf(fp2, "%d \n",Resultado);
		   }
	}
	
	if(Operation==8){ //XOR
		    for( i = 0 ; i < vectorSize ; i++ ) 
		   {
			  
			  Signo1 = (rand() % 2);
			  Signo1 = (int)pow(-1,Signo1);
			  *(ArrayRS1 + i) = Signo1*(rand() % (AlcanceNumerico+1)) ;
			  Signo1 = (rand() % 2);
			  Signo1 = (int)pow(-1,Signo1);
			  *(ArrayRS2 + i) = Signo1*(rand() % (AlcanceNumerico+1))  ;
			  Resultado = *(ArrayRS1 + i) ^ *(ArrayRS2 + i);

			  strcpy(BinarioNumero,dec2bin(*(ArrayRS1 + i),wordsize)); // Así se copian  los string
			  fprintf(fp, "%s \t",BinarioNumero);
			  fprintf(fp1, "%d \t",*(ArrayRS1 + i));
			  
			  strcpy(BinarioNumero,dec2bin(*(ArrayRS2 + i),wordsize)); // Así se copian  los string
			  fprintf(fp, "%s \n",BinarioNumero);
			  fprintf(fp1, "%d \n",*(ArrayRS2 + i));
			  
			  fprintf(fp2, "%d \n",Resultado);
		   }
	}
	
	if(Operation==9){ //Set Less Than
		   if(signed1orUnsigned==1){ // Signed
			   for( i = 0 ; i < vectorSize ; i++ ) 
			   {
				  
				  Signo1 = (rand() % 2);
				  Signo1 = (int)pow(-1,Signo1);
				  *(ArrayRS1 + i) = Signo1*(rand() % (AlcanceNumerico+1)) ;
				  Signo1 = (rand() % 2);
				  Signo1 = (int)pow(-1,Signo1);
				  *(ArrayRS2 + i) = Signo1*(rand() % (AlcanceNumerico+1))  ;
				  if(*(ArrayRS1 + i) < *(ArrayRS2 + i)) Resultado = 1;
				  else Resultado = 0;
				 
				  strcpy(BinarioNumero,dec2bin(*(ArrayRS1 + i),wordsize)); // Así se copian  los string
				  fprintf(fp, "%s \t",BinarioNumero);
				  fprintf(fp1, "%d \t",*(ArrayRS1 + i));
				  
				  strcpy(BinarioNumero,dec2bin(*(ArrayRS2 + i),wordsize)); // Así se copian  los string
				  fprintf(fp, "%s \n",BinarioNumero);
				  fprintf(fp1, "%d \n",*(ArrayRS2 + i));
				  
				  fprintf(fp2, "%d \n",Resultado);
			   }
			}
			else{ //unsigned
				
			}
	}
	
	if(Operation==10){ //BEQ
		    for( i = 0 ; i < vectorSize ; i++ ) 
		   {
			  
			  Signo1 = (rand() % 2);
			  Signo1 = (int)pow(-1,Signo1);
			  *(ArrayRS1 + i) = Signo1*(rand() % (AlcanceNumerico+1)) ;
			  Signo1 = (rand() % 2);
			  Signo1 = (int)pow(-1,Signo1);
			  *(ArrayRS2 + i) = Signo1*(rand() % (AlcanceNumerico+1))  ;
			  if(*(ArrayRS2 + i)==*(ArrayRS1 + i)) Resultado = 1;
			  else Resultado = 0;

			  strcpy(BinarioNumero,dec2bin(*(ArrayRS1 + i),wordsize)); // Así se copian  los string
			  fprintf(fp, "%s \t",BinarioNumero);
			  fprintf(fp1, "%d \t",*(ArrayRS1 + i));
			  
			  strcpy(BinarioNumero,dec2bin(*(ArrayRS2 + i),wordsize)); // Así se copian  los string
			  fprintf(fp, "%s \n",BinarioNumero);
			  fprintf(fp1, "%d \n",*(ArrayRS2 + i));
			  
			  fprintf(fp2, "%d \n",Resultado);
		   }
	}
	
	if(Operation==12){ //  DIV
		   if(signed1orUnsigned==1){ // Signed
			   for( i = 0 ; i < vectorSize ; i++ ) 
			   {
				  
				  Signo1 = (rand() % 2);
				  Signo1 = (int)pow(-1,Signo1);
				  *(ArrayRS1 + i) = (Signo1*(rand() % (AlcanceNumerico+1)))-1 ;
				  Signo1 = (rand() % 2);
				  Signo1 = (int)pow(-1,Signo1);
				  *(ArrayRS2 + i) = Signo1*(rand() % (AlcanceNumerico+1))  ;
				  if(*(ArrayRS2 + i) == 0) Resultado = -1;
				  else if( *(ArrayRS1 + i) == (-1*((int)pow(2,wordsize-1)))  ){
					 if(*(ArrayRS2 + i) == -1)  Resultado = (-1*((int)pow(2,wordsize-1)));
				  }
				  else Resultado = *(ArrayRS1 + i) / *(ArrayRS2 + i);
				 
				  strcpy(BinarioNumero,dec2bin(*(ArrayRS1 + i),wordsize)); // Así se copian  los string
				  fprintf(fp, "%s \t",BinarioNumero);
				  fprintf(fp1, "%d \t",*(ArrayRS1 + i));
				  
				  strcpy(BinarioNumero,dec2bin(*(ArrayRS2 + i),wordsize)); // Así se copian  los string
				  fprintf(fp, "%s \n",BinarioNumero);
				  fprintf(fp1, "%d \n",*(ArrayRS2 + i));
				  
				  fprintf(fp2, "%d \n",Resultado);
			   }
			}
			else{ //unsigned
				
			}
	}
	
	if(Operation==13){ //  REM
		   if(signed1orUnsigned==1){ // Signed
			   for( i = 0 ; i < vectorSize ; i++ ) 
			   {
				  
				  Signo1 = (rand() % 2);
				  Signo1 = (int)pow(-1,Signo1);
				  *(ArrayRS1 + i) = (Signo1*(rand() % (AlcanceNumerico+1)))-1 ;
				  Signo1 = (rand() % 2);
				  Signo1 = (int)pow(-1,Signo1);
				  *(ArrayRS2 + i) = Signo1*(rand() % (AlcanceNumerico+1))  ;
				  if(*(ArrayRS2 + i) == 0) Resultado = *(ArrayRS1 + i);
				  else Resultado = *(ArrayRS1 + i) % *(ArrayRS2 + i);
				 
				  strcpy(BinarioNumero,dec2bin(*(ArrayRS1 + i),wordsize)); // Así se copian  los string
				  fprintf(fp, "%s \t",BinarioNumero);
				  fprintf(fp1, "%d \t",*(ArrayRS1 + i));
				  
				  strcpy(BinarioNumero,dec2bin(*(ArrayRS2 + i),wordsize)); // Así se copian  los string
				  fprintf(fp, "%s \n",BinarioNumero);
				  fprintf(fp1, "%d \n",*(ArrayRS2 + i));
				  
				  fprintf(fp2, "%d \n",Resultado);
			   }
			}
			else{ //unsigned
				
			}
	}
	
	free(ArrayRS1);
	free(ArrayRS2);
	fclose(fp);
    fclose(fp1);
    fclose(fp2);
	
}

int main() {
     
    
	system("clear");	
	system("echo \"██╗   ██╗ ██████╗ ██╗ ██████╗███████╗      \"");
	system("echo \"██║   ██║██╔═══██╗██║██╔════╝██╔════╝      \"");
	system("echo \"██║   ██║██║   ██║██║██║     █████╗        \"");
	system("echo \"╚██╗ ██╔╝██║   ██║██║██║     ██╔══╝        \"");
	system("echo \" ╚████╔╝ ╚██████╔╝██║╚██████╗███████╗      \"");
	system("echo \"  ╚═══╝   ╚═════╝ ╚═╝ ╚═════╝╚══════╝      \"");
	system("echo \"                                           \"");
	system("echo \" ██████╗██╗██████╗ ██╗  ██╗███████╗██████╗ \"");
	system("echo \"██╔════╝██║██╔══██╗██║  ██║██╔════╝██╔══██╗\"");
	system("echo \"██║     ██║██████╔╝███████║█████╗  ██████╔╝\"");
	system("echo \"██║     ██║██╔═══╝ ██╔══██║██╔══╝  ██╔══██╗\"");
	system("echo \"╚██████╗██║██║     ██║  ██║███████╗██║  ██║\"");
	system("echo \" ╚═════╝╚═╝╚═╝     ╚═╝  ╚═╝╚══════╝╚═╝  ╚═╝\"");
	system("echo \"                                           \"");
	sleep(1);
	system("clear");
	
	
	
	WINDOW *w;
    char list[15][24] = { "Word Length","Test Vector Length","Add", "Left Shift", "Right Shift", "Arithmetic Right Shift", "And Logical" , "Or Logical", "Xor Logical","Set Less Than", "Branch Equal","Multiplication","Division","Remainder","Quit"};
    char item[24];
    int ch, i = 0, width = 24;
    int signed1=0;
	int wordsize=3;
	int MULTTYPE1=0;
	int vectorsize=5;
	
    initscr(); // initialize Ncurses

    w = newwin( 17, 27, 1, 1 ); // create a new window
    box( w, 0, 0 ); // sets default borders for the window
     
// now print all the menu items and highlight the first one
    for( i=0; i<15; i++ ) {
        if( i == 0 ) 
            wattron( w, A_STANDOUT ); // highlights the first item.
        else
            wattroff( w, A_STANDOUT );
        sprintf(item, "%-24s",  list[i]);
        mvwprintw( w, i+1, 2, "%s", item );
    }
 
    wrefresh( w ); // update the terminal screen
 
    i = 0;
    noecho(); // disable echoing of characters on the screen
    keypad( w, TRUE ); // enable keyboard input for the window.
    curs_set( 0 ); // hide the default screen cursor.
     
       // get the input
    while(( ch = wgetch(w)) != 'q'){ 
         
                // right pad with spaces to make the items appear with even width.
            sprintf(item, "%-24s",  list[i]); 
            mvwprintw( w, i+1, 2, "%s", item ); 
              // use a variable to increment or decrement the value based on the input.
            switch( ch ) {
                case KEY_UP:
                            i--;
                            i = ( i<0 ) ? 14 : i;
                            break;
                case KEY_DOWN:
                            i++;
                            i = ( i>14 ) ? 0 : i;
                            break;
                case KEY_RIGHT: 
                            if(i==0){ //Word Length Option
								wordsize= menuWordLenght(wordsize);
								clear();   // Clean the environment ncurses
								refresh();
								box( w, 0, 0 ); // Draw again the main windows
								refresh();    // Refresh the main windows
							}
							if(i==1){ //Word Length Option
								vectorsize= menuTestVector(vectorsize);
								clear();   // Clean the environment ncurses
								refresh();
								box( w, 0, 0 ); // Draw again the main windows
								refresh();    // Refresh the main windows
							}
							if(i==2){ //Add
								menuEjecutando();
								GoldenReferences(i,vectorsize,wordsize,i); //second i it is not neccessary
								clear();   // Clean the environment ncurses
								refresh();
								box( w, 0, 0 ); // Draw again the main windows
								refresh();    // Refresh the main windows
							}
							if(i==3){ //Left Shift
								menuEjecutando();
								GoldenReferences(i,vectorsize,wordsize,i);  //second i it is not neccessary
								clear();   // Clean the environment ncurses
								refresh();
								box( w, 0, 0 ); // Draw again the main windows
								refresh();    // Refresh the main windows
							}
							if(i==4){ //Right Shift
								menuEjecutando();
								GoldenReferences(i,vectorsize,wordsize,i);  //second i it is not neccessary
								clear();   // Clean the environment ncurses
								refresh();
								box( w, 0, 0 ); // Draw again the main windows
								refresh();    // Refresh the main windows
							}
							if(i==6){ //AND
								menuEjecutando();
								GoldenReferences(i,vectorsize,wordsize,i); //second i it is not neccessary
								clear();   // Clean the environment ncurses
								refresh();
								box( w, 0, 0 ); // Draw again the main windows
								refresh();    // Refresh the main windows
							}
							if(i==7){ //OR
								menuEjecutando();
								GoldenReferences(i,vectorsize,wordsize,i); //second i it is not neccessary
								clear();   // Clean the environment ncurses
								refresh();
								box( w, 0, 0 ); // Draw again the main windows
								refresh();    // Refresh the main windows
							}
							if(i==8){ //XOR  ////second i it is not neccessary
								menuEjecutando();
								GoldenReferences(i,vectorsize,wordsize,i);
								clear();   // Clean the environment ncurses
								refresh();
								box( w, 0, 0 ); // Draw again the main windows
								refresh();    // Refresh the main windows
							}
                            if(i==9){ //Set Less Than ... Option
								menuSignedUnsigned(10,i,vectorsize,wordsize);
								clear();   // Clean the environment ncurses
								refresh();
								box( w, 0, 0 ); // Draw again the main windows
								refresh();    // Refresh the main windows
							}
							if(i==10){ //BEQ
								menuEjecutando();
								GoldenReferences(i,vectorsize,wordsize,i); //second i it is not neccessary
								clear();   // Clean the environment ncurses
								refresh();
								box( w, 0, 0 ); // Draw again the main windows
								refresh();    // Refresh the main windows
							}
							if(i==11){ //Mult Option
								MULTTYPE1= menuMUL(MULTTYPE1);
								clear();   // Clean the environment ncurses
								refresh();
								box( w, 0, 0 ); // Draw again the main windows
								refresh();    // Refresh the main windows
							}
                            if(i==12){ //Division Option
								menuSignedUnsigned(13,i,vectorsize,wordsize);
								clear();   // Clean the environment ncurses
								refresh();
								box( w, 0, 0 ); // Draw again the main windows
								refresh();    // Refresh the main windows
							}
                            if(i==13){ //Remainder Option
								menuSignedUnsigned(14,i,vectorsize,wordsize);
								clear();   // Clean the environment ncurses
								refresh();
								box( w, 0, 0 ); // Draw again the main windows
								refresh();    // Refresh the main windows
							}
                            if(i==14) //Quit Option
								goto QUIT1;
                            break;
            }
            // now highlight the next item in the list.
            wattron( w, A_STANDOUT );
             
            sprintf(item, "%-24s",  list[i]);
            mvwprintw( w, i+1, 2, "%s", item);
            wattroff( w, A_STANDOUT );
    }
	QUIT1: { }
	
    delwin( w );
    endwin();
   
    return 1;
}





/*
// Salir de un while
//Método 1
goto error;

error: {
		
}

//Método 2

break;

//Método 3

exit(1); //Mata todo el programa
*/


/*
wordsize= menuWordLenght(wordsize);
clear();   // Clean the environment ncurses
refresh();
box( w, 0, 0 ); // Draw again the main windows
refresh();    // Refresh the main windows
* 
* char listmenu2[11][7] = { "256","512","1024","4096","16384","32758","65536","131072","262144","524288","1048576"};
*/


// 10 para la SET LESS THAN
// 13 para la Division
// 14 para el residuo

/*

char listmenu2[5][52] = {"////////////////////////////////////////////////",
		                     "///                                          ///",
		                     "///      Calculando Modelo de Referencia     ///",
		                     "///                                          ///",
		                     "////////////////////////////////////////////////"}; // */
