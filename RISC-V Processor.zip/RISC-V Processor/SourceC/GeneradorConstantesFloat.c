#include <stdio.h>
#include <stdlib.h>

void GeneradorFloatLogaritmoConstantes(int n);

void ReduccionArreglo() ;




char StringHexByte0 [32];  //Byte 0 LSB
char StringHexByte1 [32];  //Byte 1
char StringHexByte2 [32];  // Byte 2
char StringHexByte3 [32];  //Byte 3 MSB

char StringBinary [32]; // String que almacena una posición en específico de l archivo  ConstantesRAM.txt

int main() {



    int n;    // Variable n del tamaño en bits del arreglo


    printf("Introduzca el número de elementos que desea que tenga la serie Taylor para aproximar el logaritmo debe ser un número par: ");  // Solicita al usuario el número de elementos que se desea que tenga la serie
    scanf("%d",&n);


    GeneradorFloatLogaritmoConstantes(n);






    // **************+Archivo donde  se guardan las constantes de una memoria RAM ***********************
    FILE * fpInput;
    fpInput = fopen("/home/carlos/XilinxMicroprocesadorMulticiclo/ConstantesRAM.txt","r");

    //***************Archivo de carga de datos de la RAM del microprocesador
    FILE * fp0;
    fp0 = fopen ("/home/carlos/XilinxMicroprocesadorMulticiclo/DatosRAMByte0.txt", "w+");

    FILE * fp1;
    fp1 = fopen ("/home/carlos/XilinxMicroprocesadorMulticiclo/DatosRAMByte1.txt", "w+");

    FILE * fp2;
    fp2 = fopen ("/home/carlos/XilinxMicroprocesadorMulticiclo/DatosRAMByte2.txt", "w+");

    FILE * fp3;
    fp3 = fopen ("/home/carlos/XilinxMicroprocesadorMulticiclo/DatosRAMByte3.txt", "w+");

    FILE * fp4;
    fp4 = fopen ("/home/carlos/XilinxMicroprocesadorMulticiclo/DatosRAMByte4.txt", "w+");

    FILE * fp5;
    fp5 = fopen ("/home/carlos/XilinxMicroprocesadorMulticiclo/DatosRAMByte5.txt", "w+");

    FILE * fp6;
    fp6 = fopen ("/home/carlos/XilinxMicroprocesadorMulticiclo/DatosRAMByte6.txt", "w+");

    FILE * fp7;
    fp7 = fopen ("/home/carlos/XilinxMicroprocesadorMulticiclo/DatosRAMByte7.txt", "w+");

    if (fp0 == NULL || fp1 == NULL || fp2 == NULL || fp3 == NULL || fp4 == NULL || fp5 == NULL || fp6 == NULL || fp7 == NULL || fpInput == NULL) {
       printf("No existe el archivo\n");
       return EOF; // Para evitar violación de segmento en caso de que no exista el archivo
    }



    int f = 0;
    int par = 0;  // indica si es el primer byte o el segundo, si es un float el primero se guarda en la parte baja y el segundo se guarda en ela parte alta

    while (f<n +2) // Se le pone más 2 porque se le agregarón 2 elementos
    {
        //fgets (StringBinary, n, fpInput);
        fscanf(fpInput,"%s",StringBinary);

        //printf("El dato a la entrada es: %s . \n",StringBinary);
        ReduccionArreglo();
        //printf("El Byte 3 de la iteración %d es: %s . \n",f,StringHexByte3);
        //printf("El Byte 2 de la iteración %d es: %s . \n",f,StringHexByte2);
        //printf("El Byte 1 de la iteración %d es: %s . \n",f,StringHexByte1);
        //printf("El Byte 0 de la iteración %d es: %s . \n",f,StringHexByte0);

        if(par == 0){
            fprintf(fp3, "%s \n",StringHexByte3);  // Byte 3 MSB
            fprintf(fp2, "%s \n",StringHexByte2);  // Byte 2
            fprintf(fp1, "%s \n",StringHexByte1);  // Byte 1
            fprintf(fp0, "%s \n",StringHexByte0);  // Byte 0 LSB
            par = 1;
        }
        else {
            fprintf(fp7, "%s \n",StringHexByte3);  // Byte 3 MSB
            fprintf(fp6, "%s \n",StringHexByte2);  // Byte 2
            fprintf(fp5, "%s \n",StringHexByte1);  // Byte 1
            fprintf(fp4, "%s \n",StringHexByte0);  // Byte 0 LSB
            par = 0;
        }
        f++;
     }









    fclose(fpInput);

    fclose(fp0);
    fclose(fp1);
    fclose(fp2);
    fclose(fp3);

    fclose(fp4);
    fclose(fp5);
    fclose(fp6);
    fclose(fp7);












    return 1;

}



void GeneradorFloatLogaritmoConstantes(int n){  // Genera en un archivo llamado ConstantesRAM.txt las constantes del logaritmo
    int i;   // Variable del for

    float A,B;  // Operando A y B de la suma en punto flotante

    // ***********   Punteros a archivos  ***********************

    FILE * fpY;

    //**************** Se abren los archivos *************************

    fpY = fopen ("/home/carlos/XilinxMicroprocesadorMulticiclo/ConstantesRAM.txt", "w+");

    if(fpY  == NULL) {
        printf("Error! opening file");
        exit(1);         /* Program exits if file pointer returns NULL. */
    }


    // Conversión del flotante al ieee754
    union converter{
    float f_val;
    unsigned int u_val;
    };




    // Se genera el 1/i, desde i = 1 hasta n, sirve para la constante de división de la serie de taylor del logaritmo

    // In(1+x) = \sum_{i=1} ^{n} ( ( (-1)^(i+1) ) * x ^ i )/ i

    char Zero[8] = "00000000";

    // Se crean las constantes del logartimo
    // Primera constante 0
    // Segunda constante 1/1
    // Tercera constante 1/2
    // cuarta constante 1/3
    // N      constante 1/N
	float signo = -1;
    for( i = -1 ; i < n+1 ; i++ ) {
        if(i==-1) { // Constante Zero al inicio
            fprintf(fpY,"%s \n",Zero);
            i++; //se imcrementa para que no caida en una división por cero
        }
        else{
            A = (float)((signo)/i);
            union converter Aop;
            Aop.f_val = A;
            fprintf(fpY,"%x \n",Aop.u_val);       // Se almacena la representación IEEE 754 en formato hexadecimal del número A
        }
        if(signo == -1.0f) signo = 1.0f;
        else signo = -1.0f;
        
    }




    // Esto no se necesita se debe borrar es solo para pruebas. Cuando se borre se debe recordar poner un 0 en ese espacio de direcciones

    float NNUM;    // Variable que almacena el número flotante al que se le desea calcular el logaritmo

    printf("Introduzca el número al que se le desea calcular el logaritmo natural: ");  // Solicita al usuario el número de elementos que se desea que tenga la serie
    scanf("%f",&NNUM);

    union converter Aop2;
    Aop2.f_val = NNUM;
    fprintf(fpY,"%x \n",Aop2.u_val);       // Se almacena la representación IEEE 754 en formato hexadecimal del número A






    fclose(fpY);


}


void ReduccionArreglo() // Se separa los 4 bytes qu estan juntos  en 4 bytes separados para escribirse en el archivo
{
    int n;


    for (n=0;n<=7;n++){
        if(n==0 || n==1)
            StringHexByte3[n] = StringBinary[n];    // Byte 3 MSB
        else if (n==2 || n==3)
            StringHexByte2[n-2] = StringBinary[n];  // Byte 2
        else if (n==4 || n==5)
            StringHexByte1[n-4] = StringBinary[n];  // Byte 1
        else
            StringHexByte0[n-6] = StringBinary[n];  // Byte 0 LSB
    }
}
