#include <stdio.h>
#include <stdlib.h>
#include <string.h>

int main() {

    FILE * fp1;
    fp1 = fopen ("CodigoProgramaHIGH.txt", "r"); 
    int i=0;
    int dirinicio =32768;
	int programStart = 15;
	int dirend;
	int k = 0;
	int bits=0;
    
    if (fp1 == NULL) {
	   printf("No existe el archivo\n");
	   return EOF; // Para evitar violación de segmento en caso de que no exista el archivo
	}
    else
   {
	   while (!feof(fp1) ) //Mientras no se detecte fin de archivo;
	   {
			i++;
			fgetc(fp1);
	   }
	}  
	i = (i-1)/4; // Esto siempre da un número diferente por eso se escala
	
	for (k=0;k<=32;k++){  
		if( (int)pow(2,k) >= i){
			bits= k;
			break;
		}
	}
	
	printf("\nLa memoria ROM debe tener: %d direcciones \n",i);
	printf("El parámetro de la ROM llamado ROM_ADDR_BITS debe colocarse en: %d.\n",bits);
	printf("El parámetro de la ROM llamado ROM_ADDR_START_BITS debe colocarse en: %d.\n",programStart);
	
	dirend = dirinicio + i -1;
	
	printf("El parámetro de la ROM llamado BEGIN_ADDR_ROM_PROGRAM debe colocarse en: 0x%02X\n",dirinicio);
	printf("El parámetro de la ROM llamado END_ADDR_ROM_PROGRAM debe colocarse en: 0x%02X\n",dirend);
	fclose(fp1);

	return 1;
}


