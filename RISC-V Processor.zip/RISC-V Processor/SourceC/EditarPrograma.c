#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>
// Las instrucciones vienen empaquetadas 2 juntas, por esta razón se usan estos char, en uno se almacena
// los 8 hex de la primer instrucción y en el otro los 8 hex de la segunda instrucción
char StringHexPrimero [32]; 
char StringHexSegundo [32]; 

char StringHexPrimeraByte0 [32];  //Byte LSB Memory LOW
char StringHexPrimeraByte1 [32];  //Byte 1 Memory Low
char StringHexPrimeraByte2 [32];  // Byte 2 Memory High
char StringHexPrimeraByte3 [32];  //Byte MSB Memory High

char StringHexSegundoByte0 [32];  //Byte LSB Memory LOW
char StringHexSegundoByte1 [32];  //Byte 1 Memory Low
char StringHexSegundoByte2 [32];  // Byte 2 Memory High
char StringHexSegundoByte3 [32];  //Byte MSB Memory High

void bin2decimal(char NumBin[]);

int main() {

    char StringBinary [32]; 
    char str1[32]; //String utilizado para comparar si es una instrucción o son ceros
    strcpy(str1, "0000000000000000"); // se inicializa con todos en cero para comparar

    // **************+Archivo del ISE binario***********************
    FILE * fp1;
    fp1 = fopen("Programa.txt","r");
    
    //***************Archivo donde se van a guardar el programa entero *******************
    FILE * fp2;
    fp2 = fopen ("CodigoPrograma.txt", "w+"); 
    
    //***************Archivo donde se van a guardar la parte baja de las instrucciones  *******************
    FILE * fp3;
    fp3 = fopen ("CodigoProgramaLOW.txt", "w+");
    
    //***************Archivo donde se van a guardar la parte alta de las instrucciones *******************
    FILE * fp4;
    fp4 = fopen ("CodigoProgramaHIGH.txt", "w+");
    
    int j;  // Variable para solicitarle al usuario el número del largo del arreglo
    int f = 0; //Variable para el while que se va incrementando
    
    printf("Tamaño del arreglo en bits típicamente es 15 es el depth que se seleccionó al compilar elf2hex: ");  
    // Solicita al usuario el número de bits del archivo binario xilinx.txt por ejemplo si hay 1024 datos entonces son 10 bits lo que se coloca
    scanf("%d",&j);
    
    int BeginAddress, EndAddress, SizeProgram,k,control,contador;
    
    printf( "\nAbra el archivo Programa.dump, observe la dirección de inicio del programa y escribala en hexadecimal (típicamente 0x10000): " );
    scanf( "%x", &BeginAddress);
    
    printf( "\nAbra el archivo Programa.dump, observe la dirección de fin del programa y escribala en hexadecimal: " );
    scanf( "%x", &EndAddress);
    
    SizeProgram = EndAddress - BeginAddress;
    
    // Si SizeProgram no tiene sentido se sale del programa
    if(SizeProgram <= 0 ){printf("\nDigito mal el formato de palabra\n");return EOF; } //no tiene sentido el rango digitado
    
    for (k=0;k<=29;k++){  
		if( (int)pow(2,k) > SizeProgram){SizeProgram = (int)pow(2,k);k= 30;}
	}
    
    j = (int) pow(2,j); // 2**j  tamaño del archivo
    
	control = 0;
	contador = 0;
	
    SizeProgram = SizeProgram/4; //Las instrucciones estan separadas de 4 en 4 por eso se divide entre 4
    
    if (fp1 == NULL || fp2 == NULL || fp3 == NULL || fp4 == NULL) 
		{printf("No existe el archivo\n");return EOF; }// no existe algun archivo el archivo
    else
   {
	   while (f<j) //Mientras no se detecte fin de archivo;
	   {
				fgets (StringBinary, j, fp1); 
				bin2decimal(StringBinary);
				if(strncmp(StringBinary,str1,16) != 0){control = 1;}
				
				if(control == 1){
					if(contador < SizeProgram){
						fprintf(fp2, "%s \n",StringHexPrimero);
						fprintf(fp2, "%s \n",StringHexSegundo);
						
						fprintf(fp3, "%s \n",StringHexPrimeraByte0);  // Byte 0 LSB de la instrucción 1
						fprintf(fp3, "%s \n",StringHexPrimeraByte1);  // Byte 1 de la instrucción 1
						
						fprintf(fp3, "%s \n",StringHexSegundoByte0);  // Byte 0 LSB de la instrucción 2
						fprintf(fp3, "%s \n",StringHexSegundoByte1);  // Byte 1 de la instrucción 2
						
						fprintf(fp4, "%s \n",StringHexPrimeraByte2);  // Byte 2 LSB de la instrucción 1
						fprintf(fp4, "%s \n",StringHexPrimeraByte3);  // Byte 3 de la instrucción 1
						
						fprintf(fp4, "%s \n",StringHexSegundoByte2);  // Byte 2 LSB de la instrucción 2
						fprintf(fp4, "%s \n",StringHexSegundoByte3);  // Byte 3 de la instrucción 2
						
					}
					contador++;
				}
				
				if(contador >= SizeProgram && (strncmp(StringBinary,str1,16) != 0)){ //MAnejo de errores mal definido el rango
					printf("\nERROR ERROR ERROR: Una instrucción no fue considerada. Solución: \n");
					printf("1) Revisar el archivo file.dump y corroborar que BeginAddress y EndAddress están bien. \n");
					printf("Dentro del programa cambiar la línea de código SizeProgram = SizeProgram/4; por SizeProgram = SizeProgram/2; \n");
					return EOF; // Se definieron mal los límites
				}
			
				f++;
		}
	}  
	
	
	fclose(fp1);fclose(fp2);fclose(fp3);fclose(fp4);
	return 1;
}

void bin2decimal(char NumBin[])
{
	int n;	
	for (n=0;n<=7;n++){  
		StringHexSegundo[n] = NumBin[n]; 
		if(n==0 || n==1)
			StringHexSegundoByte3[n] = NumBin[n];    // Byte 3 MSB
		else if (n==2 || n==3)
			StringHexSegundoByte2[n-2] = NumBin[n];  // Byte 2
		else if (n==4 || n==5)
			StringHexSegundoByte1[n-4] = NumBin[n];  // Byte 1
		else 
			StringHexSegundoByte0[n-6] = NumBin[n];  // Byte 0 LSB
	}
	
	for (n=8;n<=15;n++){ 
		StringHexPrimero[n-8] = NumBin[n]; 
		if(n==8 || n==9)
			StringHexPrimeraByte3[n-8] = NumBin[n]; //Byte 3 MSB
		else if (n==10 || n==11)
			StringHexPrimeraByte2[n-10] = NumBin[n]; // Byte 2
		else if (n==12 || n==13)
			StringHexPrimeraByte1[n-12] = NumBin[n];  // Byte 1
		else 
			StringHexPrimeraByte0[n-14] = NumBin[n]; //Byte 0 LSB
	}
	
	
}

