#include <stdio.h>
#include <stdlib.h>
#include <math.h>

// Para compilar : gcc FuncionesDivisionLogaritmo.c -o FuncionesDivisionLogaritmo.o -lm

double Division(double num, double den, double ConstantesDivision[18], double UNO, double CERO);
double LogaritmoNatural(double num, double ConstanteLogaritmo[6], double ConstanteCordic[2], double ConstanteCordicInvert[2], double CERO, double UNO);
double HMM(int o[20], double a[10][10], double b[10][32], double pi[10], double CERO, double UNO, double ConstantesDivision[18], double MenosInf, double ConstanteLogaritmo[6], double ConstanteCordic[2], double ConstanteCordicInvert[2]);

int main(){
	
	double ConstantesDivision[18] = {10000000.0f,1000000.0f, 100000.0f, 10000.0f, 1000.0f, 100.0f, 10.0f, 0.1f, 0.01f, 0.001f, 0.0001f, 0.00001f, 0.000001f, 0.0000001f, 0.5f, 2.823529412, 1.882352941, 2.0f};
	double UNO = 1.0f;
	double CERO = 0.0f;
	double MenosInf = -1e100;
	double ConstanteLogaritmo[6] = {2.718281828459045, 0.367879441171442, 0.500000000000000, 0.333333333333333, 0.250000000000000, -0.434294481903252};
	double ConstanteCordic[2] = {1.648721270700128, 1.284025416687742};
	double ConstanteCordicInvert[2] = {1.0f/1.648721270700128, 1.0f/1.284025416687742};
	
	
	double a[10][10] = {  //[fila][columna]
		{0.469643, 0.000000, 0.136022, 0.000058, 0.000000, 0.000562,          0.002234, 0.126280, 0.265201, 0.000000},
		{0.000001, 0.000000, 0.000000, 0.122919, 0.026807, 0.501227,          0.260329, 0.000000, 0.023273, 0.065445}, 
		{0.000001, 0.000000, 0.563544, 0.000000, 0.000000, 0.000000,          0.000000, 0.078351, 0.358104, 0.000000}, 
		{0.073891, 0.000000, 0.000000, 0.674719, 0.000000, 0.019568,          0.000000, 0.000000, 0.183326, 0.048497},
		{0.000000, 0.000000, 0.000000, 0.000000, 0.972638, 0.000000,          0.000000, 0.000000, 0.000000, 0.027362},
		{0.284698, 0.000000, 0.000000, 0.000000, 0.000000, 0.575226,          0.045556, 0.068007, 0.026513, 0.000000},
		{0.000000, 0.000000, 0.052266, 0.000000, 0.052834, 0.042763,          0.722944, 0.000000, 0.095921, 0.033272},
		{0.000000, 0.000000, 0.000000, 0.000000, 0.000000, 0.150616,          0.000000, 0.838361, 0.000014, 0.011009},
		{0.041688, 0.000000, 0.000000, 0.004357, 0.000000, 0.000494,          0.002159, 0.000004, 0.951298, 0.000000}, 
		{0.000000, 0.000000, 0.000000, 0.000000, 0.000000, 0.067966,          0.054257, 0.027643, 0.002597, 0.847537}
	};
	
	
	double b[10][32] = {  //[fila][columna]
		{0.000000, 0.000000, 0.000000, 0.000000, 0.000000, 0.986157,          0.000000, 0.000000, 0.000000, 0.003209, 0.000014, 0.000000,           0.000000, 0.000000, 0.000000, 0.000000, 0.000000, 0.000000,          0.000000, 0.000000, 0.000000, 0.000000, 0.000000, 0.000000,        0.000000, 0.000000, 0.000000, 0.000000, 0.000000, 0.010619,                   0.000000, 0.000000},
		{0.000000, 0.000000, 0.000000, 0.000000, 0.000000, 0.000000,          0.000000, 0.000000, 0.000000, 0.000000, 0.000000, 0.000000,           0.000000, 1.000000, 0.000000, 0.000000, 0.000000, 0.000000,          0.000000, 0.000000, 0.000000, 0.000000, 0.000000, 0.000000,        0.000000, 0.000000, 0.000000, 0.000000, 0.000000, 0.000000,                   0.000000, 0.000000}, 
		{0.000000, 0.000000, 0.000000, 0.000000, 0.448416, 0.000000,          0.000000, 0.000000, 0.000000, 0.514209, 0.000000, 0.000000,           0.000000, 0.000000, 0.000000, 0.000000, 0.000000, 0.000000,          0.000000, 0.000000, 0.000000, 0.000000, 0.037375, 0.000000,        0.000000, 0.000000, 0.000000, 0.000000, 0.000000, 0.000000,                   0.000000, 0.000000},
		{0.000000, 0.000000, 0.000000, 0.000000, 0.049456, 0.157342,          0.000000, 0.000000, 0.000000, 0.000000, 0.000000, 0.000000,           0.000000, 0.000000, 0.000000, 0.000000, 0.000000, 0.000000,          0.000000, 0.000000, 0.000000, 0.000000, 0.000000, 0.000000,        0.000000, 0.000000, 0.793201, 0.000000, 0.000000, 0.000000,                   0.000000, 0.000000},
		{0.000000, 0.000000, 0.000000, 0.000000, 0.000000, 0.136076,          0.000000, 0.000000, 0.000000, 0.000000, 0.000000, 0.000000,           0.000000, 0.000000, 0.000000, 0.000000, 0.000000, 0.000000,          0.000000, 0.000000, 0.000000, 0.000000, 0.000000, 0.000000,        0.000000, 0.000000, 0.840160, 0.000000, 0.023764, 0.000000,                   0.000000, 0.000000}, 
		{0.000000, 0.000000, 0.000000, 0.000000, 0.000000, 0.885540,          0.000000, 0.114460, 0.000000, 0.000000, 0.000000, 0.000000,           0.000000, 0.000000, 0.000000, 0.000000, 0.000000, 0.000000,          0.000000, 0.000000, 0.000000, 0.000000, 0.000000, 0.000000,        0.000000, 0.000000, 0.000000, 0.000000, 0.000000, 0.000000,                   0.000000, 0.000000},
		{0.267766, 0.000000, 0.000000, 0.000000, 0.000000, 0.000000,          0.000000, 0.029156, 0.000000, 0.000000, 0.000000, 0.018678,           0.000000, 0.000000, 0.000000, 0.000000, 0.000000, 0.000000,          0.000000, 0.000000, 0.000000, 0.000000, 0.000000, 0.000000,        0.000000, 0.000000, 0.000000, 0.000000, 0.082843, 0.601557,                   0.000000, 0.000000},
		{0.000000, 0.000000, 0.000000, 0.000000, 0.000000, 0.027391,          0.000000, 0.014321, 0.000000, 0.000000, 0.744658, 0.000000,           0.000000, 0.000000, 0.000000, 0.000000, 0.061037, 0.122074,          0.000000, 0.030519, 0.000000, 0.000000, 0.000000, 0.000000,        0.000000, 0.000000, 0.000000, 0.000000, 0.000000, 0.000000,                   0.000000, 0.000000},
		{0.000000, 0.000000, 0.000000, 0.000000, 0.000000, 0.963714,          0.000000, 0.002978, 0.000000, 0.000000, 0.024707, 0.000000,           0.000000, 0.000000, 0.000000, 0.000000, 0.000000, 0.000000,          0.000000, 0.000000, 0.000000, 0.000000, 0.000000, 0.000000,        0.000000, 0.000000, 0.005079, 0.000000, 0.000000, 0.003521,                   0.000000, 0.000000},
		{0.000000, 0.000000, 0.000000, 0.000000, 0.000000, 0.000000,          0.000000, 0.862760, 0.000000, 0.000000, 0.000000, 0.137240,           0.000000, 0.000000, 0.000000, 0.000000, 0.000000, 0.000000,          0.000000, 0.000000, 0.000000, 0.000000, 0.000000, 0.000000,        0.000000, 0.000000, 0.000000, 0.000000, 0.000000, 0.000000,                   0.000000, 0.000000}
	};
	
	double pi[10] = {0.000000, 0.976744, 0.000000, 0.000000, 0.000000, 0.000000,          0.000000, 0.000000, 0.023256, 0.000000};
	
	//int o[20] = {13,5,5,29,29,7,7,7,29,7,5,5,5,10,10,10,10,5,5,5}; // No converge 
	int o[20] = {5, 5, 5, 5, 29, 29, 7, 7, 7, 7, 5, 5, 26, 28, 29, 7, 7, 7, 7, 7}; // Si converge a -12.858346
		
	double result;
	double num, den;
	
	num = 20.0;
	den = 50.0f;
	
	result = Division(num,den,ConstantesDivision,UNO, CERO);
	printf( "El resultado de dividir %f entre %f es: %f \n", num, den, result);
	
	result = LogaritmoNatural(num, ConstanteLogaritmo, ConstanteCordic, ConstanteCordicInvert, CERO, UNO);
	printf( "El resultado del logaritmo natural del número %e es: %f \n", num, result);
	
	
	result = HMM( o, a, b, pi, CERO, UNO, ConstantesDivision, MenosInf, ConstanteLogaritmo, ConstanteCordic, ConstanteCordicInvert);
	printf( "El resultado del hmm es: %e \n", result);
	
	return 1;
	
}

double Division(double num, double den, double ConstantesDivision[18], double UNO, double CERO){
	double escala = UNO; // Variable Escala
	double Xi; // Aproximacion del recíproco del denominador 1/den
	double Div; // Divisor es la salida del módulo
	int loopp = 1; // Variable utilizada para salir del while
	int N; // Cantidad de iteraciones necesarias para que la iteración
	int x; // Variabble del indice del for para el método Newton Raphson
	
	if (den<CERO) // Validación para que sirva para cualquier valor de den
	{
		den = -den;
		num = -num;
	}
	
	int borrar=1;
	//**************** Escala el denominador a un rango entre 0.1 y 1 ***************************
	while (loopp ==1){  
		//printf( "La iteración es : %d \n", borrar );   // Para verificación
		//borrar = borrar + 1;
		if (den > UNO)
		{	
			//printf( "Entro al if de Denominador >1 \n");   // Para verificación
			if (den > ConstantesDivision[0]) //10 000 000
			{
				escala = escala* ConstantesDivision[13];
				den = den * ConstantesDivision[13];
			}
			else if (den > ConstantesDivision[1]) // 1 000 000
			{
				escala = escala* ConstantesDivision[12];
				den = den* ConstantesDivision[12];
			}
			else if (den > ConstantesDivision[2]) // 100 000
			{
				escala = escala* ConstantesDivision[11];
				den = den* ConstantesDivision[11];
			}
			else if (den > ConstantesDivision[3]) // 10 000
			{
				escala = escala * ConstantesDivision[10];
				den = den * ConstantesDivision[10];
			}
			else if (den > ConstantesDivision[4]) // 1 000
			{
				escala = escala * ConstantesDivision[9];
				den = den * ConstantesDivision[9];
			}
			else if (den > ConstantesDivision[5]) // 100
			{
				escala = escala * ConstantesDivision[8];
				den = den * ConstantesDivision[8];
			}
			else  // 10
			{	
				//printf( "Entro al else den > 10. El denominador es: %e. Y la escala es %e. \n",den, escala);   // Para verificación
				escala = escala* ConstantesDivision[7];
				den = den* ConstantesDivision[7];
				//printf( "Entro al else den > 10. El denominador es: %e. Y la escala es %e. \n",den, escala);   // Para verificación
			}
		}
		else 
		{
			if (den< ConstantesDivision[11])  // 0.00001
			{
				escala = escala * (ConstantesDivision[2]);  // 100 000
				den = den* (ConstantesDivision[2]);
			}
			else if (den< ConstantesDivision[10]) // 0.0001
			{
				escala = escala * (ConstantesDivision[3]);  // 10 000
				den = den* (ConstantesDivision[3]);
			}
			else if (den< ConstantesDivision[9])  // 0.001
			{
				escala = escala * (ConstantesDivision[4]);  // 1 000
				den = den* (ConstantesDivision[4]);
			}
			else if (den< ConstantesDivision[8])  // 0.01
			{
				escala = escala * (ConstantesDivision[5]);  // 100
				den = den* (ConstantesDivision[5]);
			}
			else if (den< ConstantesDivision[7])  // 0.1 
			{
				escala = escala * (ConstantesDivision[6]);  // 10
				den = den* (ConstantesDivision[6]);
			}
			else loopp = 0;
		}

	}
	
	//printf( "La escala es es: %e \n", escala );   // Para verificación
	//printf( "El denominador es: %e \n", den );   // Para verificación
	
	//**************** Determina el número de iteraciones
	
	if  (den> (ConstantesDivision[14])) N=4;
	else N=6;
	
	//**************** Estimación inicial
	Xi=(ConstantesDivision[15]) -  ((ConstantesDivision[16]) *den); // Xi=(48/17)-(32/17)*D
	
	//*************** Newton Raphson
	for (x = 1; x <= N; x++ ) {
		Xi = (Xi*(ConstantesDivision[17] -den*Xi));   // Xi = Xi*(2-D*Xi);
	}
	
	//****************  Realiza la división de los números
	if (num==UNO) // Si numerador es 1
	{
		if (escala == UNO) Div = Xi; // Si no hay escala
		else Div = Xi*escala; // Si sí hubo escala
	}
	else  // Si numerador no es 1
	{
		if (escala == UNO) Div = Xi*num; // Si no hay escala
		else Div = Xi*num*escala;	// Si sí hubo escala
	}

	return Div;
}



double LogaritmoNatural(double num, double ConstanteLogaritmo[6], double ConstanteCordic[2], double ConstanteCordicInvert[2], double CERO, double UNO){
	int k = 0; // indice de los primeros whiles
	int i; // índice del for para determinar pesos
	double w[2]; // El tamaño tiene que ser igual hasta donde llega el for de los pesos, si el  for de pesos es desde 1 hasta 2, se coloca en 2 esta variable
	double ai; // Variable auxiliar para determinar los pesos
	double poweroftwo; // Variable que se utiliza en el último for del algoritmo
	double fx; // Variable donde se almacena el  resultado del logaritmo 
	double kf; // Variable kf en flotanrte
	
	kf = CERO;
	while (ConstanteLogaritmo[0] <= num){  // si e <= num
		k = k + 1;
		kf = UNO + kf;
		num = num * ConstanteLogaritmo[1]; // num = num / e;
	}
	
	while (num < UNO){   // se num < 1.0f
		k = k - 1; 
		kf = kf - UNO;  
		num = num * ConstanteLogaritmo[0]; // num = num * e;
	}
	
	
	// Determinando los pesos
	for (i = 0; i < 2; i++ ) { // for i = 1: n, donde n es el número de iteraciones, para este caso se coloca en 2
		w[i] = 0;                                 // w(i) = 0.0;
		ai = ConstanteCordic[i]; // ai = a(i);
		if (ai < num)
		{
			w[i] = UNO;                                // w(i) = 1.0;
			num = num * ConstanteCordicInvert[i];  // num = num / ai;
		}
	}
	
	num = num - UNO;
	num = num * (UNO - (num * ConstanteLogaritmo[2]))* (UNO + (num * ConstanteLogaritmo[3])) * (UNO - (num * ConstanteLogaritmo[4]));



	poweroftwo = ConstanteLogaritmo[2]; // poweroftwo = 0.5;
	for (i = 0; i < 2; i++ ) { // for i = 1: n, donde n es el número de iteraciones, para este caso se coloca en 2
		num = num + (w[i]*poweroftwo);
		poweroftwo = poweroftwo * ConstanteLogaritmo[2];
	}
	
	fx = kf + num;
	
	return fx;
}


double HMM(int o[20], double a[10][10], double b[10][32], double pi[10], double CERO, double UNO, double ConstantesDivision[18], double MenosInf, double ConstanteLogaritmo[6], double ConstanteCordic[2], double ConstanteCordicInvert[2]){
	
	int T = 20; //  Longitud de la secuencia de observación, cantidad de símbolos utilizados para la clasificación
	int N = 10; //  Longitud de la matriz A
	double ct[20];
	
	double alpha[20][10]; 
	int i, t, j; //Variable para el for
	double z; // Alpha parcial utilizado en el cálculo de αt(i)
	double logProb; // Variable del logaritmo de la Probabilidad
	int error = 0; // Indica que existe división por cero

	// Compute α0 (i)
	ct[0] = CERO;
	for(i = 0; i <= N-1; i = i + 1 ){
		alpha[0][i] = b[i][o[0]]*pi[i];  // Alpha 
		ct[0] = ct[0] + alpha[0][i];
    }
	
	
	
    // scale the α0 (i)
    if(ct[0] == CERO)
    { 
		error = 1;
	}
    else
    {
		 ct[0] = Division(UNO,ct[0],ConstantesDivision,UNO,CERO); // ct[0] = 1/ct[0];
	}

	if(error == 0)
	{
		for(i = 0; i <= N-1; i = i + 1 ){
			alpha[0][i] = ct[0]*alpha[0][i];
		}
	}
	

	// compute αt(i)
	if(error == 0)
	{
		for (t = 1; t <= T-1; t = t + 1 ){
			ct[t] = CERO;
			for (i = 0; i <= N-1; i = i + 1 ){
				z=CERO;                   // Alpha
				for (j = 0; j <= N-1; j = j + 1 ){
					z=z+a[i][j]*alpha[t-1][j];
				}
				alpha[t][i]=z*b[i][o[t]];
				ct[t] = ct[t] + alpha[t][i];
			} 
			//printf( "El coeficiente ct[%d] es: %f \n",t, ct[t]);  // Para verificación
			
			if(ct[t] == CERO) // Si es cero, significa que esa observación no servirá
			{
				error = 1;
				t = 100; // Se pone en 100 para que acabe el algoritmo
			}
			else
			{
				ct[t] = Division(UNO,ct[t],ConstantesDivision,UNO, CERO); // ct[t] = 1/ct[t];
			}

			// scale αt(i)
			for (i = 0; i <= N-1; i = i + 1 ){
				printf( "El coeficiente alpha[%d][%d] sin escala es: %f. El factor de escala es ct[%d] es: %f",t, i, alpha[t][i], t,ct[t]);  // Para verificación
				alpha[t][i] = ct[t]*alpha[t][i];
				printf( "El coeficiente alpha[%d][%d] es: %f \n",t, i, alpha[t][i]);  // Para verificación
			}
		}
	}
	
	// Compute log[P (O | λ)]
	
	if (error == 1)
	{
		logProb = MenosInf;
	}
	else
	{
		logProb = UNO; 
		for (i = 0; i <= T-1; i = i + 1 ){
			logProb = logProb*ct[i];    //logProb = logProb + log10(ct[i]);
		}
		logProb = LogaritmoNatural(logProb, ConstanteLogaritmo, ConstanteCordic, ConstanteCordicInvert, CERO, UNO);   //logProb = log10(logProb);
		logProb = logProb*ConstanteLogaritmo[5];  // Se multiplica el logaritmo natural por la constante -log(e)
	}


	return logProb;
}

	

