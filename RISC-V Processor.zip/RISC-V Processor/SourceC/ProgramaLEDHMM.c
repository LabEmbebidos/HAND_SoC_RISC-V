// Descripción de funcionamiento:
// Programa que calcula tres HMM  y después deja un LED blinking 
// Fue el primer HMM que funcionó correctamente
// Sirve para ver los resultados en FPGA



double Division(double num, double den, double ConstantesDivision[18], double UNO, double CERO);
double LogaritmoNatural(double num, double ConstanteLogaritmo[6], double ConstanteCordic[2], double ConstanteCordicInvert[2], double CERO, double UNO);
double HMM(int o[20], double a[10][10], double b[10][32], double pi[10], double CERO, double UNO, double ConstantesDivision[18], double MenosInf, double ConstanteLogaritmo[6], double ConstanteCordic[2], double ConstanteCordicInvert[2]);

double Prueba(double num, double den, double ConstantesDivision[18], double UNO, double ConstanteLogaritmo[6], double ConstanteCordic[2], double ConstanteCordicInvert[2], double CERO);

 
 void main(void) {
	 
	  int t; // índice del for para inicializar constantes en general
	  int x; // Variable utilizada para inicializar las columnas de las matrices del HMM
	  int y; // Variable utilizada para inicializar las filas de las matrices del HMM
	  //**********************Inicializar constantes básicas ***************************
	  double *DirZERO = (double*)0x0400;  // Dirección base donde hay un 0 almacenado
	  double CERO; // Variable que va almacenar el 0
	  CERO = *DirZERO;
	  
	  double *DirUNO = (double*)0x0408;  // Dirección base donde hay un 1 almacenado
	  double UNO;  // Variable que va almacenar el UNO
	  UNO = *DirUNO;
	  
	  //**********************Inicializar constantes división*************************** 
	  double *DivisionBase = (double*)0x0418;   //  1048 
	  double ConstantesDivision[18]; // Variable de las constantes que se utilizan en la división
	   
	  for (t=0; t<=17; t++){
			ConstantesDivision[t] = *(DivisionBase+t);
      }
      
      //*********************Inicializar constantes logaritmo natural **********************
      double *DirLogaritmoBase = (double*)0x04A8; // 1192
      double ConstanteLogaritmo[6];  // Variable de las constantes que se utilizan en el logaritmo
      for ( t = 0; t < 6; t++ ) { 
			ConstanteLogaritmo[t] = *(DirLogaritmoBase+t);
	  }
	  
	  double *DirCordic = (double*)0x04D8; // 1240
	  double ConstanteCordic[2];  // Variable de las constantes que se utilizan en el logaritmo
	  for ( t = 0; t < 2; t++ ) { 
			ConstanteCordic[t] = *(DirCordic+t);
	  }
	  
	  double *DirCordicInv = (double*)0x04E8; // 1256
	  double ConstanteCordicInvert[2];  // Variable de las constantes que se utilizan en el logaritmo
	  for ( t = 0; t < 2; t++ ) { 
			ConstanteCordicInvert[t] = *(DirCordicInv+t);
	  }
	  
	  
	  //****************************Inicializar matrices Bosque ***************************************************
	  double *DirMatrizABosque = (double*)0x04F8; // 1272
	  double ABosque[10][10];
	  t=0;
	  
	  for ( y = 0; y < 10; y++ ) { // Se almacenan las constantes  Abosque
		for ( x = 0; x < 10; x++ ) {
			ABosque[y][x] = *(DirMatrizABosque+t);
			t++;
		}
	  }
	  
	  double *DirMatrizBBosque = (double*)0x0818; // 2072
	  double BBosque[10][32];
	  t=0;
	  
	  for ( y = 0; y < 10; y++ ) { // Se almacenan las constantes  Bbosque
		for ( x = 0; x < 32; x++ ) {
			BBosque[y][x] = *(DirMatrizBBosque+t);
			t++;
		}
	  }
	  
	  double *DirMatrizPiBosque = (double*)0x1218; // 4632
	  double PiBosque[10];
	  
	  for ( t = 0; t < 10; t++ ) { 
			PiBosque[t] = *(DirMatrizPiBosque+t);
	  }
	  
	  
	  
	  //****************************Inicializar matrices Motosierra  ***************************************************
	  double *DirMatrizAMotosierra = (double*)0x1268; // 4712
	  double AMotosierra[10][10];
	  t=0;
	  
	  for ( y = 0; y < 10; y++ ) { // Se almacenan las constantes  AMotosierra
		for ( x = 0; x < 10; x++ ) {
			AMotosierra[y][x] = *(DirMatrizAMotosierra+t);
			t++;
		}
	  }
	  
	  double *DirMatrizBMotosierra = (double*)0x1588; // 5512
	  double BMotosierra[10][32];
	  t=0;
	  
	  for ( y = 0; y < 10; y++ ) { // Se almacenan las constantes  BMotosierra
		for ( x = 0; x < 32; x++ ) {
			BMotosierra[y][x] = *(DirMatrizBMotosierra+t);
			t++;
		}
	  }
	  
	  double *DirMatrizPiMotosierra = (double*)0x1F88; // 8072
	  double PiMotosierra[10];
	  
	  for ( t = 0; t < 10; t++ ) { 
			PiMotosierra[t] = *(DirMatrizPiMotosierra+t);
	  }
	  
	  
	  //****************************Inicializar matrices Disparo  ***************************************************
	  double *DirMatrizADisparo = (double*)0x1FD8; // 8152
	  double ADisparo[10][10];
	  t=0;
	  
	  for ( y = 0; y < 10; y++ ) { // Se almacenan las constantes  ADisparo
		for ( x = 0; x < 10; x++ ) {
			ADisparo[y][x] = *(DirMatrizADisparo+t);
			t++;
		}
	  }
	  
	  double *DirMatrizBDisparo = (double*)0x22F8; // 8952
	  double BDisparo[10][32];
	  t=0;
	  
	  for ( y = 0; y < 10; y++ ) { // Se almacenan las constantes  BDisparo
		for ( x = 0; x < 32; x++ ) {
			BDisparo[y][x] = *(DirMatrizBDisparo+t);
			t++;
		}
	  }
	  
	  double *DirMatrizPiDisparo = (double*)0x2CF8; // 11512
	  double PiDisparo[10];
	  
	  for ( t = 0; t < 10; t++ ) { 
			PiDisparo[t] = *(DirMatrizPiDisparo+t);
	  }
	  
	  
	  //****************************  Constante menos infinito***************************************
	  
	  double *DirMenosInfinito = (double*)0x2D48; // 11592
	  double MenosInfinito;
	  
	  MenosInfinito = *DirMenosInfinito;
	  
	  // ************************** Símbolos*********************************************************
	  
	  int *DirSimbolo = (int*)0x2D50;         //  11600
	  int O[20];
	  
	  for ( t = 0; t < 20; t++ ) { 
			O[t] = *(DirSimbolo+t);
	  }
	  
	  
	  
	  
	  
	  
	  
	  float *ResultadoOut = (float*)0x0080;   //  128
	  double *NUMA = (double*)0x0440;   //  1088     100
	  double *NUMB = (double*)0x04D0;   //  1232     -log(e)
	  double nummA;
	  double nummB; 
	  double result;
	  
	  nummA = *NUMA; 
	  nummB = *NUMB;
	  
	  
	  // Para verificación***
	  //*ResultadoOut = nummA;
	  //*ResultadoOut = nummB;
	  
	  //result = LogaritmoNatural(nummA, ConstanteLogaritmo, ConstanteCordic, ConstanteCordicInvert, CERO, UNO);
	  //*ResultadoOut = result ;
	  
	  
	  
	  //result = Division(nummB, nummB, ConstantesDivision, UNO, CERO);

	  //*ResultadoOut = result ;
	  
	  result = HMM(O, ABosque, BBosque, PiBosque, CERO, UNO, ConstantesDivision, MenosInfinito, ConstanteLogaritmo, ConstanteCordic, ConstanteCordicInvert);
	  
	  *ResultadoOut = result ;
	  
	  result = HMM(O, AMotosierra, BMotosierra, PiMotosierra, CERO, UNO, ConstantesDivision, MenosInfinito, ConstanteLogaritmo, ConstanteCordic, ConstanteCordicInvert);
	  
	  *ResultadoOut = result ;
	  
	  result = HMM(O, ADisparo, BDisparo, PiDisparo, CERO, UNO, ConstantesDivision, MenosInfinito, ConstanteLogaritmo, ConstanteCordic, ConstanteCordicInvert);
	  
	  
	  *ResultadoOut = result ;
	  
	  
	  // Blink de un LED dentro de un while 1***************************
	  int i = 0;
	  int *LED = (int*)0x0040; //64
	  *LED = 0;
	  while(i<1000000){
		 i++;
		 if(i==1000000){
			 *LED =  ~*LED;		
			 i =  0;
		 }
	  } 
	  
	   
}

//******************************************** ALGORITMO DE DIVISION BASADO EN NEWTON RAPHSON******************************

double Division(double num, double den, double ConstantesDivision[18], double UNO, double CERO){
	double escala = UNO; // Variable Escala
	double Xi; // Aproximacion del recíproco del denominador 1/den
	double Div; // Divisor es la salida del módulo
	int loopp = 1; // Variable utilizada para salir del while
	int N; // Cantidad de iteraciones necesarias para que la iteración
	int x; // Variabble del indice del for para el método Newton Raphson
	
	if (den<CERO) // Validación para que sirva para cualquier valor de den
	{
		den = -den;
		num = -num;
	}
	
	int borrar=1;
	//**************** Escala el denominador a un rango entre 0.1 y 1 ***************************
	while (loopp ==1){  
		//printf( "La iteración es : %d \n", borrar );   // Para verificación
		//borrar = borrar + 1;
		if (den > UNO)
		{	
			//printf( "Entro al if de Denominador >1 \n");   // Para verificación
			if (den > ConstantesDivision[0]) //10 000 000
			{
				escala = escala* ConstantesDivision[13];
				den = den * ConstantesDivision[13];
			}
			else if (den > ConstantesDivision[1]) // 1 000 000
			{
				escala = escala* ConstantesDivision[12];
				den = den* ConstantesDivision[12];
			}
			else if (den > ConstantesDivision[2]) // 100 000
			{
				escala = escala* ConstantesDivision[11];
				den = den* ConstantesDivision[11];
			}
			else if (den > ConstantesDivision[3]) // 10 000
			{
				escala = escala * ConstantesDivision[10];
				den = den * ConstantesDivision[10];
			}
			else if (den > ConstantesDivision[4]) // 1 000
			{
				escala = escala * ConstantesDivision[9];
				den = den * ConstantesDivision[9];
			}
			else if (den > ConstantesDivision[5]) // 100
			{
				escala = escala * ConstantesDivision[8];
				den = den * ConstantesDivision[8];
			}
			else  // 10
			{	
				//printf( "Entro al else den > 10. El denominador es: %e. Y la escala es %e. \n",den, escala);   // Para verificación
				escala = escala* ConstantesDivision[7];
				den = den* ConstantesDivision[7];
				//printf( "Entro al else den > 10. El denominador es: %e. Y la escala es %e. \n",den, escala);   // Para verificación
			}
		}
		else 
		{
			if (den< ConstantesDivision[11])  // 0.00001
			{
				escala = escala * (ConstantesDivision[2]);  // 100 000
				den = den* (ConstantesDivision[2]);
			}
			else if (den< ConstantesDivision[10]) // 0.0001
			{
				escala = escala * (ConstantesDivision[3]);  // 10 000
				den = den* (ConstantesDivision[3]);
			}
			else if (den< ConstantesDivision[9])  // 0.001
			{
				escala = escala * (ConstantesDivision[4]);  // 1 000
				den = den* (ConstantesDivision[4]);
			}
			else if (den< ConstantesDivision[8])  // 0.01
			{
				escala = escala * (ConstantesDivision[5]);  // 100
				den = den* (ConstantesDivision[5]);
			}
			else if (den< ConstantesDivision[7])  // 0.1 
			{
				escala = escala * (ConstantesDivision[6]);  // 10
				den = den* (ConstantesDivision[6]);
			}
			else loopp = 0;
		}

	}
	
	//printf( "La escala es es: %e \n", escala );   // Para verificación
	//printf( "El denominador es: %e \n", den );   // Para verificación
	
	//**************** Determina el número de iteraciones
	
	if  (den> (ConstantesDivision[14])) N=4;
	else N=6;
	
	//**************** Estimación inicial
	Xi=(ConstantesDivision[15]) -  ((ConstantesDivision[16]) *den); // Xi=(48/17)-(32/17)*D
	
	//*************** Newton Raphson
	for (x = 1; x <= N; x++ ) {
		Xi = (Xi*(ConstantesDivision[17] -den*Xi));   // Xi = Xi*(2-D*Xi);
	}
	
	//****************  Realiza la división de los números
	if (num==UNO) // Si numerador es 1
	{
		if (escala == UNO) Div = Xi; // Si no hay escala
		else Div = Xi*escala; // Si sí hubo escala
	}
	else  // Si numerador no es 1
	{
		if (escala == UNO) Div = Xi*num; // Si no hay escala
		else Div = Xi*num*escala;	// Si sí hubo escala
	}

	return Div;
}

double LogaritmoNatural(double num, double ConstanteLogaritmo[6], double ConstanteCordic[2], double ConstanteCordicInvert[2], double CERO, double UNO){
	int k = 0; // indice de los primeros whiles
	int i; // índice del for para determinar pesos
	double w[2]; // El tamaño tiene que ser igual hasta donde llega el for de los pesos, si el  for de pesos es desde 1 hasta 2, se coloca en 2 esta variable
	double ai; // Variable auxiliar para determinar los pesos
	double poweroftwo; // Variable que se utiliza en el último for del algoritmo
	double fx; // Variable donde se almacena el  resultado del logaritmo 
	double kf; // Variable kf en flotanrte
	
	kf = CERO;
	while (ConstanteLogaritmo[0] <= num){  // si e <= num
		k = k + 1;
		kf = UNO + kf;
		num = num * ConstanteLogaritmo[1]; // num = num / e;
	}
	
	while (num < UNO){   // se num < 1.0f
		k = k - 1; 
		kf = kf - UNO;  
		num = num * ConstanteLogaritmo[0]; // num = num * e;
	}
	
	
	// Determinando los pesos
	for (i = 0; i < 2; i++ ) { // for i = 1: n, donde n es el número de iteraciones, para este caso se coloca en 2
		w[i] = 0;                                 // w(i) = 0.0;
		ai = ConstanteCordic[i]; // ai = a(i);
		if (ai < num)
		{
			w[i] = UNO;                                // w(i) = 1.0;
			num = num * ConstanteCordicInvert[i];  // num = num / ai;
		}
	}
	
	num = num - UNO;
	num = num * (UNO - (num * ConstanteLogaritmo[2]))* (UNO + (num * ConstanteLogaritmo[3])) * (UNO - (num * ConstanteLogaritmo[4]));



	poweroftwo = ConstanteLogaritmo[2]; // poweroftwo = 0.5;
	for (i = 0; i < 2; i++ ) { // for i = 1: n, donde n es el número de iteraciones, para este caso se coloca en 2
		num = num + (w[i]*poweroftwo);
		poweroftwo = poweroftwo * ConstanteLogaritmo[2];
	}
	
	fx = kf + num;
	
	return fx;
}




double HMM(int o[20], double a[10][10], double b[10][32], double pi[10], double CERO, double UNO, double ConstantesDivision[18], double MenosInf, double ConstanteLogaritmo[6], double ConstanteCordic[2], double ConstanteCordicInvert[2]){
	
	int T = 20; //  Longitud de la secuencia de observación, cantidad de símbolos utilizados para la clasificación
	int N = 10; //  Longitud de la matriz A
	double ct[20];
	
	double alpha[20][10]; 
	int i, t, j; //Variable para el for
	double z; // Alpha parcial utilizado en el cálculo de αt(i)
	double logProb; // Variable del logaritmo de la Probabilidad
	int error = 0; // Indica que existe división por cero
	
	//float *ResultadoOut = (float*)0x0080;   //  128  Para verificación

	// Compute α0 (i)
	ct[0] = CERO;
	for(i = 0; i <= N-1; i = i + 1 ){
		alpha[0][i] = b[i][o[0]]*pi[i];  // Alpha 
		ct[0] = ct[0] + alpha[0][i];
    }
    
    

    // scale the α0 (i)
    if(ct[0] == CERO)
    { 
		error = 1;
	}
    else
    {
		 ct[0] = Division(UNO,ct[0],ConstantesDivision,UNO,CERO); // ct[0] = 1/ct[0];
	}

	if(error == 0)
	{
		for(i = 0; i <= N-1; i = i + 1 ){
			alpha[0][i] = ct[0]*alpha[0][i];
		}
	}
	

	// compute αt(i)
	if(error == 0)
	{
		for (t = 1; t <= T-1; t = t + 1 ){
			ct[t] = CERO;
			for (i = 0; i <= N-1; i = i + 1 ){
				z=CERO;                   // Alpha
				for (j = 0; j <= N-1; j = j + 1 ){
					z=z+a[i][j]*alpha[t-1][j];
				}
				alpha[t][i]=z*b[i][o[t]];
				ct[t] = ct[t] + alpha[t][i];
			} 
			
			//*ResultadoOut = ct[t];  // Para verificación************************************************
			if(ct[t] == CERO) // Si es cero, significa que esa observación no servirá
			{
				error = 1;
				t = 100; // Se pone en 100 para que acabe el algoritmo
			}
			else
			{
				ct[t] = Division(UNO,ct[t],ConstantesDivision,UNO, CERO); // ct[t] = 1/ct[t];
			}
			//*ResultadoOut = ct[t];  // Para verificación************************************************

			// scale αt(i)
			for (i = 0; i <= N-1; i = i + 1 ){
				alpha[t][i] = ct[t]*alpha[t][i];
			}
		}
	}
	
	// Compute log[P (O | λ)]
	
	if (error == 1)
	{
		logProb = MenosInf;
	}
	else
	{
		logProb = UNO; 
		for (i = 0; i <= T-1; i = i + 1 ){
			logProb = logProb*ct[i];    //logProb = logProb + log10(ct[i]);
		}
		logProb = LogaritmoNatural(logProb, ConstanteLogaritmo, ConstanteCordic, ConstanteCordicInvert, CERO, UNO);   //logProb = log10(logProb);
		logProb = logProb*ConstanteLogaritmo[5];  // Se multiplica el logaritmo natural por la constante -log(e)
	}


	return logProb;
}



double Prueba(double num, double den, double ConstantesDivision[18], double UNO, double ConstanteLogaritmo[6], double ConstanteCordic[2], double ConstanteCordicInvert[2], double CERO){
	
	double result;
	
	result = Division(num, den, ConstantesDivision, UNO, CERO);
	
	result = LogaritmoNatural(result, ConstanteLogaritmo, ConstanteCordic, ConstanteCordicInvert, CERO, UNO);
	 
	return result ;
 
}

/*



float logaritmoNatural(float num){
	
	
	/////////////////////////////////////////////// ALgoritmo Serie de Taylor/////////////////////////////////
	//********************                 infinito                                                         //
	//********************                                     i - 1        i                               //
	//********************   Ln(1+x) = sumatoria           (-1)      *    x                                 //
	//********************                                 ------------------     ; Válido para |x| < 1     //
	//********************                 i = 1                    i                                       //
	//********************                                                                                  //
	//////////////////////////////////////////////////////////////////////////////////////////////////////////
	
	
	
	//////////////////////////////////////////////// Puntos importantes /////////////////////////////////////
	//  Nótese que se necesita averiguar x y como Ln(num) = Ln(1+x)
	//  Esto implica que                          num = 1 + x;
	//  FInalmente se tiene                       x = num -1 ; 
	//
	//  Por lo que si se desea calcular el logaritmo a un número, siempre se le debe restar un offset igual
	//  a -1 a ese número.
	
	
	float result;
	
	float mult; // Variable que realiza el x^n en la serie de taylor; 
	
	int i; // iteración de la serie de taylor, por la definición del logaritmo natural inicia en i = 1;
    float sum; // Se encarga de llevar la suma de la serie de taylor
	
	//float *DirConstantZero = (float*)0x0400; // Apunta a la primer posición de memoria de datos de la RAM que es igual a zero
	
	float Division; // Variable que va a almacenar el resultado de x^n o -x^n dividido entre i. En realidad se hace una multiplicación por 1/i
	
	float Div[100]; // Arreglo de float que va a almacenar el contenido de las direcciones de memoria donde esta la RAM
	
	
	//**********************************Direcciones de memoria donde se encuentran guardados los 1/i*****
	float *initial = (float*)0x0400;  // Dirección initial donde hay un 0 en memoria

	
	
	
	// *******************Se inicializa las constantes en memoria de la división 1/i *****************************
	for (i = 1;  i <= 100; i++){
		Div[i] = *(initial + i);
	}
	
	
	
	 
	
	
	
	mult =  Div[1];  // Por defecto para que el algoritmo funcione mult debe ser igual a 1 en el momento inicial.
  
    num = num -Div[1];  // Se le resta el número al offset, Es decir al numero que se le desea calcular el logaritmo se le resta 1 x= num -1
	
	sum = *initial; // La variable suma se le asigna el contenido cero.
	
	
	//inicia el algoritmo******************************
	
	for (i = 1;  i <= 100; i++){
	   mult = mult*num;   // => potencia x^i
	   Division = mult*Div[i]; // Se multiplica el resultado de la potencia por la constante (1/i)*(-1)^(i-1), esta constante ya se genera incluso con signo por lo que es una simple multiplicación, esto se hace para ganar rendimiento
	   sum = Division + sum; // se realiza la sumatoria
	}

	result = sum;
	return result;
}   

*/
