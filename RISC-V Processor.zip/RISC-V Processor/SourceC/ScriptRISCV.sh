

#!/bin/bash
# Script para realizar más eficientemente el proceso de compilación en RISC-V
# Asume que la compilación en risc-v siempre se realizará en el directorio home
# Para usar se le debe dar permisos de la siguiente forma: chmod a+x ScriptRISCV.sh
# PAra ejecutarlo simplemente se realiza lo siguiente: ./ScriptRISCV.sh
# Compila el código C dentro de la carpte SourceC  que esta en dropbox y se llama Programa.c


clear

echo "Cambiando directorio a home" 
cd ../../../../../
sleep 0.5

echo "Exportando variables de entorno RISC-V"
export TOP=$(pwd)
export RISCV=$TOP/riscv
export PATH=$PATH:$RISCV/bin


export TOP=$(pwd)
export RISCV=$TOP/riscv
export PATH=$PATH:$RISCV/bin
## Se agregan las variables de ambiente de 32 bits ##Esto es nuevo se acaba de agregar
cd ../../opt/
export TOP=$(pwd)
export RISCV=$TOP/riscv32i
export PATH=$PATH:$RISCV/bin
cd ../home/carlos/
sleep 0.5

echo "Compilando código C con el toolchain de RISC-V, genera archivo Codigo.o"
##riscv64-unknown-elf-gcc /home/carlos/Dropbox/TesisMaestria/SourceFileMicro/itcr-dcilab/SourceC/Programa.c -o Programa.o -lm -m32 -march=RV32IM   ## Se comento esto
riscv32-unknown-elf-gcc /home/carlos/Dropbox/TesisMaestria/SourceFileMicro/itcr-dcilab/SourceC/Programa.c -o Programa.o -lm -m32 -march=RV32IMFD ##-msoft-float     ## Se agrego esto en lugar de lo comentado
sleep 4

 

echo "Generando archivo ensamblador Codigo.dump"
##riscv64-unknown-elf-objdump -d Programa.o > Programa.dump  ## Se comento esto
riscv32-unknown-elf-objdump -d Programa.o > Programa.dump   ## Se agrego esto
sleep 0.5

echo "Generando código fuente Codigo.txt" #Si se llega a cambiar el 32768 por otro número debe compilarse nuevamente el EditarPrograma.c
elf2hex 8 32768 Programa.o > Programa.txt
sleep 0.5

echo "Regresando al directorio de trabajo"
cd Dropbox/TesisMaestria/SourceFileMicro/itcr-dcilab/SourceC/
sleep 0.5

echo "Ejecutando programa para tratamiento de archivo Codigo.txt"
sleep 0.5
clear
./EditarPrograma.o

sleep 2
echo "Copiando CodigoPrograma.txt, CodigoProgramaLOW.txt y CodigoProgramaHIGH.txt en directorio SourceC de Assembla"
cp /home/carlos/XilinxMicroprocesadorMulticiclo/CodigoPrograma.txt /home/carlos/Dropbox/TesisMaestria/SourceFileMicro/itcr-dcilab/SourceC/
cp /home/carlos/XilinxMicroprocesadorMulticiclo/CodigoProgramaLOW.txt /home/carlos/Dropbox/TesisMaestria/SourceFileMicro/itcr-dcilab/SourceC/
cp /home/carlos/XilinxMicroprocesadorMulticiclo/CodigoProgramaHIGH.txt /home/carlos/Dropbox/TesisMaestria/SourceFileMicro/itcr-dcilab/SourceC/

sleep 2
echo "Calculando el tamaño del parámetro ROM_ADDR_BITS"
./FileSize.o
