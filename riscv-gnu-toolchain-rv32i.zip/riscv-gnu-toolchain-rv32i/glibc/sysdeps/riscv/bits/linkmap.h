struct link_map_machine
  {
    ElfW(Addr) plt; /* Address of .plt */
  };
