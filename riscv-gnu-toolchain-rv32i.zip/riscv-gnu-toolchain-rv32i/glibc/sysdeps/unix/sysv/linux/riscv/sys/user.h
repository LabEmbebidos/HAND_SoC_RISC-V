/* x86 puts "struct user_regs_struct" in here, this is just a shim. */
#include <asm/ptrace.h>
