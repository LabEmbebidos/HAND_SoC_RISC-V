/* We can use the ix86 version.  */
#include <sysdeps/unix/sysv/linux/i386/profil-counter.h>
