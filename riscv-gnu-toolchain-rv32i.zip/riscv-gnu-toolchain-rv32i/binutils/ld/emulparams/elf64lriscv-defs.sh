. ${srcdir}/emulparams/elf32lriscv-defs.sh
